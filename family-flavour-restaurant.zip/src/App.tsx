import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { OnlineMenu } from './components/OnlineMenu';
import { ReservationSystem } from './components/ReservationSystem';
import { PhotoGallery } from './components/PhotoGallery';
import { Testimonials } from './components/Testimonials';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { OrderDrawer } from './components/OrderDrawer';
import { QuickActionBar } from './components/QuickActionBar';
import { MenuItem } from './types';
import { RESTAURANT_INFO } from './data/restaurantInfo';
import { MessageSquare, Phone } from 'lucide-react';

export default function App() {
  const [activeSection, setActiveSection] = useState('hero');
  const [cart, setCart] = useState<{ [itemId: string]: number }>({});
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Scroll tracking to update active link
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['hero', 'about', 'menu', 'reservation', 'gallery', 'testimonials', 'contact'];
      const scrollPos = window.scrollY + 200;

      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el && el.offsetTop <= scrollPos) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavigate = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleAddToCart = (item: MenuItem) => {
    setCart((prev) => ({
      ...prev,
      [item.id]: (prev[item.id] || 0) + 1
    }));
  };

  const handleUpdateCartQty = (itemId: string, delta: number) => {
    setCart((prev) => {
      const current = prev[itemId] || 0;
      const next = current + delta;
      if (next <= 0) {
        const copy = { ...prev };
        delete copy[itemId];
        return copy;
      }
      return { ...prev, [itemId]: next };
    });
  };

  const handleClearCart = () => {
    setCart({});
  };

  const cartCount: number = (Object.values(cart) as number[]).reduce((sum, qty) => sum + (qty || 0), 0);

  return (
    <div className="min-h-screen bg-[#120e0b] text-[#f5eedb] flex flex-col selection:bg-amber-500 selection:text-stone-950 pb-16 sm:pb-0">
      {/* Sticky Navigation */}
      <Navbar
        activeSection={activeSection}
        onNavigate={handleNavigate}
        cartCount={cartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenReservation={() => handleNavigate('reservation')}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          onExploreMenu={() => handleNavigate('menu')}
          onBookTable={() => handleNavigate('reservation')}
        />

        {/* Heritage & About Section */}
        <AboutSection />

        {/* Online Interactive Menu */}
        <OnlineMenu
          cart={cart}
          onAddToCart={handleAddToCart}
          onUpdateCartQty={handleUpdateCartQty}
          onOpenCart={() => setIsCartOpen(true)}
        />

        {/* Table Reservation System */}
        <ReservationSystem />

        {/* Photo Gallery with Lightbox */}
        <PhotoGallery />

        {/* Guest Reviews & Testimonials */}
        <Testimonials />

        {/* Contact, Timings & Accessibility Location */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer onNavigate={handleNavigate} />

      {/* Side Slide-Over Drawer for Platter / Pre-Order */}
      <OrderDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQty={handleUpdateCartQty}
        onClearCart={handleClearCart}
        onOpenReservation={() => {
          setIsCartOpen(false);
          handleNavigate('reservation');
        }}
      />

      {/* Mobile Floating Quick Action Bottom Bar */}
      <QuickActionBar
        onNavigate={handleNavigate}
        cartCount={cartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenReservation={() => handleNavigate('reservation')}
      />

      {/* Floating Desktop WhatsApp Button */}
      <div className="hidden sm:block fixed bottom-6 right-6 z-40">
        <a
          id="desktop-floating-whatsapp"
          href={RESTAURANT_INFO.phone.whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2.5 px-4 py-3 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-2xl shadow-emerald-950/80 hover:shadow-emerald-500/30 transition-all transform hover:-translate-y-1 group"
          title="Direct WhatsApp Reservation & Inquiries"
        >
          <MessageSquare className="w-5 h-5 fill-white text-emerald-600" />
          <span className="hidden md:inline">Instant WhatsApp Chat</span>
        </a>
      </div>
    </div>
  );
}
