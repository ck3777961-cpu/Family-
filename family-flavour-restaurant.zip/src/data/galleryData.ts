import { GalleryImage } from '../types';

export const GALLERY_IMAGES: GalleryImage[] = [
  {
    id: 'gal-1',
    title: 'Signature Purani Dilli Butter Chicken',
    category: 'dishes',
    url: 'https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?auto=format&fit=crop&w=1200&q=85',
    description: 'Slow-simmered over charcoal in copper handi with artisanal butter and fresh cilantro.'
  },
  {
    id: 'gal-2',
    title: 'The Royal Family Diwan Dining Hall',
    category: 'ambiance',
    url: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=85',
    description: 'Intricately decorated Mughal-inspired family dining hall with warm lighting and comfortable seating.'
  },
  {
    id: 'gal-3',
    title: 'Live Clay Tandoor & Skewers',
    category: 'heritage',
    url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=85',
    description: 'Our traditional clay ovens burning at 450°C, producing smoky succulent tikkas and naan.'
  },
  {
    id: 'gal-4',
    title: 'Hyderabadi Dum Pukht Biryani',
    category: 'dishes',
    url: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=1200&q=85',
    description: 'Layered Basmati rice fragrant with saffron, mint, fried onions, and braised meat.'
  },
  {
    id: 'gal-5',
    title: 'Family Celebrations & Festivities',
    category: 'family',
    url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=85',
    description: 'Multi-generational families coming together to share hearty meals and create lasting memories.'
  },
  {
    id: 'gal-6',
    title: 'Evening Candlelight Booths',
    category: 'ambiance',
    url: 'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?auto=format&fit=crop&w=1200&q=85',
    description: 'Intimate dining alcoves bathed in warm amber tones, ideal for quiet discussions and anniversaries.'
  },
  {
    id: 'gal-7',
    title: 'Char-grilled Angara Paneer Tikka',
    category: 'dishes',
    url: 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=1200&q=85',
    description: 'Fresh farm cottage cheese marinated in crushed whole spices and stone-ground mustard.'
  },
  {
    id: 'gal-8',
    title: 'Heritage Spice Grinding & Secret Masalas',
    category: 'heritage',
    url: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=1200&q=85',
    description: 'Whole spices roasted in small batches to preserve natural volatile aromatic oils.'
  },
  {
    id: 'gal-9',
    title: 'The Maharaja Grand Family Thali Table',
    category: 'family',
    url: 'https://images.unsplash.com/photo-1610057099431-d73a1c9d2f2f?auto=format&fit=crop&w=1200&q=85',
    description: 'Our show-stopping family banquet feast serving up to four guests on silver-plated thalis.'
  }
];

export const GALLERY_CATEGORIES = [
  { id: 'all', label: 'All Photos' },
  { id: 'dishes', label: 'Signature Dishes' },
  { id: 'ambiance', label: 'Royal Ambiance' },
  { id: 'family', label: 'Family Moments' },
  { id: 'heritage', label: 'Kitchen & Heritage' }
] as const;
