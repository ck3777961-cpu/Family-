import { Review } from '../types';

export const RESTAURANT_INFO = {
  name: 'Family Flavour Restaurant',
  tagline: 'Royal Indian Dining & Generous Family Hospitality',
  established: '1998',
  address: {
    street: 'Taj East Gate Road, Near Shilpgram Cultural Complex',
    city: 'Agra',
    state: 'Uttar Pradesh',
    pincode: '282001',
    country: 'India',
    landmark: '500m from Taj Mahal East Gate Parking & VIP Shuttle Hub'
  },
  phone: {
    primary: '+91 98370 12345',
    secondary: '+91 562 222 4567',
    whatsapp: '+91 98370 12345',
    whatsappLink: 'https://wa.me/919837012345?text=Hello%20Family%20Flavour%20Restaurant%2C%20I%20would%20like%20to%20inquire%20about%20table%20reservation%20and%20menu.'
  },
  email: 'reservations@familyflavour.com',
  timings: {
    lunch: '12:00 PM – 4:00 PM',
    dinner: '7:00 PM – 11:30 PM',
    days: 'Open All 7 Days (Including National Holidays)',
    tandoorHours: 'Live Tandoor Active from 12:30 PM & 7:15 PM'
  },
  features: [
    { title: '100% Halal & Fresh', desc: 'Sourced daily from certified local vendors with absolute freshness guarantee.' },
    { title: 'Pure Desi Ghee & Spices', desc: 'Hand-pounded stone masalas, organic clarified butter, and zero synthetic colors.' },
    { title: 'Family-Friendly Halls', desc: 'Spacious circular booths, baby high chairs, and dedicated quiet family sections.' },
    { title: 'Special Dietary Care', desc: 'Jain preparation on request, pure vegetarian kitchen section, and gluten-conscious dishes.' }
  ],
  accessibility: [
    { icon: 'Accessibility', label: 'Wheelchair Accessible', desc: 'Ground floor step-free ramp entrance & wide dining aisles.' },
    { icon: 'Car', label: 'Valet & Ample Parking', desc: 'Free secure on-site parking for cars, tourist tempo travelers & coaches.' },
    { icon: 'Baby', label: 'Kids & High Chairs', desc: 'Ergonomic baby high-chairs and mild kid-friendly meal options.' },
    { icon: 'Wifi', label: 'High-Speed Guest WiFi', desc: 'Complimentary optical fiber internet throughout the premises.' },
    { icon: 'Sparkles', label: 'Hygienic Cleanliness', desc: '5-Star FSSAI gold hygiene rated kitchen with live viewing glass.' }
  ]
};

export const REVIEWS: Review[] = [
  {
    id: 'rev-1',
    author: 'Rajesh & Sunita Sharma',
    location: 'New Delhi, India',
    rating: 5,
    date: 'August 2026',
    comment: 'We visited after exploring the Taj Mahal with our extended family of 12 people. The Maharaja Family Platter and Dal Makhani were unforgettable! The hospitality felt like dining in an emperor’s courtyard.',
    source: 'Google Reviews',
    highlightDish: 'Maharaja Grand Family Platter'
  },
  {
    id: 'rev-2',
    author: 'Emily & David Mitchell',
    location: 'London, United Kingdom',
    rating: 5,
    date: 'July 2026',
    comment: 'Best Indian food we experienced across the Golden Triangle tour! The staff accommodated our mild spice request perfectly for the Murgh Malai Tikka and Butter Chicken. Spotlessly clean with warm smiles.',
    source: 'TripAdvisor',
    highlightDish: 'Purani Dilli Butter Chicken'
  },
  {
    id: 'rev-3',
    author: 'Mohammad Farhan Akhtar',
    location: 'Lucknow, India',
    rating: 5,
    date: 'June 2026',
    comment: 'Being from Lucknow, I have high standards for Galouti Kebabs and Dum Biryani. Family Flavour exceeded every expectation. The meat was tender like silk, fragrant with rose water and cardamom.',
    source: 'DineOut',
    highlightDish: 'Galouti Kebab & Dum Biryani'
  },
  {
    id: 'rev-4',
    author: 'Pooja Agarwal & Family',
    location: 'Jaipur, India',
    rating: 5,
    date: 'May 2026',
    comment: 'Remarkable care for Jain vegetarian requirements. Freshly prepared paneer and rich Dal without onion/garlic tasted divine. Very welcoming for elders and small kids.',
    source: 'Zomato',
    highlightDish: 'Shahi Maharani Veg Royal Thali'
  }
];
