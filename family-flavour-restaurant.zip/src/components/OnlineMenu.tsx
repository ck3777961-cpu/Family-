import React, { useState, useMemo } from 'react';
import { 
  Search, 
  UtensilsCrossed, 
  Flame, 
  Sparkles, 
  Soup, 
  CookingPot, 
  Crown, 
  Wheat, 
  IceCream, 
  Coffee, 
  Plus, 
  Minus, 
  Info, 
  X, 
  ShoppingBag,
  Check
} from 'lucide-react';
import { MENU_ITEMS, MENU_CATEGORIES } from '../data/menuData';
import { MenuItem, DietaryType } from '../types';

interface OnlineMenuProps {
  cart: { [itemId: string]: number };
  onAddToCart: (item: MenuItem) => void;
  onUpdateCartQty: (itemId: string, delta: number) => void;
  onOpenCart: () => void;
}

const CATEGORY_ICONS: Record<string, React.FC<{ className?: string }>> = {
  all: UtensilsCrossed,
  starters: Flame,
  tandoor: Sparkles,
  mains: Soup,
  biryani: CookingPot,
  thali: Crown,
  breads: Wheat,
  desserts: IceCream,
  beverages: Coffee
};

export const OnlineMenu: React.FC<OnlineMenuProps> = ({
  cart,
  onAddToCart,
  onUpdateCartQty,
  onOpenCart
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [dietaryFilter, setDietaryFilter] = useState<'all' | DietaryType | 'special' | 'gluten-free'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDishForModal, setSelectedDishForModal] = useState<MenuItem | null>(null);
  const [currency, setCurrency] = useState<'INR' | 'USD'>('INR');

  const exchangeRate = 0.012; // 1 INR ~ 0.012 USD

  const formatPrice = (inrPrice: number) => {
    if (currency === 'USD') {
      return `$${(inrPrice * exchangeRate).toFixed(2)}`;
    }
    return `₹${inrPrice}`;
  };

  const filteredItems = useMemo(() => {
    return MENU_ITEMS.filter((item) => {
      // Category filter
      if (activeCategory !== 'all' && item.category !== activeCategory) {
        return false;
      }

      // Dietary filter
      if (dietaryFilter === 'veg' && item.dietary !== 'veg') return false;
      if (dietaryFilter === 'non-veg' && item.dietary !== 'non-veg') return false;
      if (dietaryFilter === 'special' && !item.isChefSpecial) return false;
      if (dietaryFilter === 'gluten-free' && !item.isGlutenFree) return false;

      // Search query
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(query);
        const matchesHindi = item.hindiName?.toLowerCase().includes(query);
        const matchesDesc = item.description.toLowerCase().includes(query);
        return matchesName || matchesHindi || matchesDesc;
      }

      return true;
    });
  }, [activeCategory, dietaryFilter, searchQuery]);

  const totalCartCount: number = (Object.values(cart) as number[]).reduce((sum, qty) => sum + (qty || 0), 0);

  return (
    <section id="menu" className="py-20 px-4 lg:px-8 bg-[#120e0b] relative">
      <div className="max-w-7xl mx-auto space-y-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-amber-400 text-xs sm:text-sm font-semibold tracking-widest uppercase flex items-center justify-center gap-1.5">
            <Sparkles className="w-4 h-4" />
            Freshly Prepared Delicacies
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#fffdf7]">
            Our Royal Dining Menu
          </h2>
          <p className="text-[#c9b7a0] text-sm sm:text-base leading-relaxed">
            Every dish is cooked fresh to order in our wood-fired clay tandoor and copper handis using family heirloom spice blends.
          </p>
        </div>

        {/* Controls Bar: Search, Dietary Filters, Currency Toggle */}
        <div className="bg-[#1a130e] p-4 sm:p-5 rounded-2xl border border-[#38281b] space-y-4 shadow-xl">
          <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
            {/* Search Input */}
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-amber-500" />
              <input
                id="menu-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search dishes, kebabs, biryani..."
                className="w-full pl-10 pr-9 py-2 rounded-xl bg-[#241a13] border border-[#4a3623] text-sm text-[#f5eedb] placeholder-[#8f7d69] focus:outline-none focus:border-amber-500 transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8f7d69] hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Dietary Filter Pills */}
            <div className="flex flex-wrap gap-2 justify-center">
              <button
                id="filter-diet-all"
                onClick={() => setDietaryFilter('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  dietaryFilter === 'all'
                    ? 'bg-amber-500 text-stone-950 shadow-md'
                    : 'bg-[#261c14] text-[#cfbfab] hover:bg-[#34261c]'
                }`}
              >
                All Dishes
              </button>

              <button
                id="filter-diet-veg"
                onClick={() => setDietaryFilter('veg')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  dietaryFilter === 'veg'
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'bg-[#261c14] text-emerald-400 hover:bg-[#34261c]'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400 border border-white"></span>
                <span>Pure Veg</span>
              </button>

              <button
                id="filter-diet-non-veg"
                onClick={() => setDietaryFilter('non-veg')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  dietaryFilter === 'non-veg'
                    ? 'bg-amber-700 text-white shadow-md'
                    : 'bg-[#261c14] text-amber-300 hover:bg-[#34261c]'
                }`}
              >
                <span className="w-2 h-2 rounded-sm bg-amber-400 border border-white rotate-45"></span>
                <span>Non-Veg</span>
              </button>

              <button
                id="filter-diet-special"
                onClick={() => setDietaryFilter('special')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  dietaryFilter === 'special'
                    ? 'bg-amber-500 text-stone-950 shadow-md'
                    : 'bg-[#261c14] text-amber-400 hover:bg-[#34261c]'
                }`}
              >
                <Crown className="w-3.5 h-3.5" />
                <span>Chef Specials</span>
              </button>

              <button
                id="filter-diet-gf"
                onClick={() => setDietaryFilter('gluten-free')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  dietaryFilter === 'gluten-free'
                    ? 'bg-amber-500 text-stone-950 shadow-md'
                    : 'bg-[#261c14] text-[#cfbfab] hover:bg-[#34261c]'
                }`}
              >
                Gluten-Conscious
              </button>
            </div>

            {/* Currency Switcher */}
            <div className="flex items-center gap-1 bg-[#241a13] p-1 rounded-xl border border-[#4a3623] text-xs">
              <span className="text-[#96836e] px-2 font-medium">Currency:</span>
              <button
                onClick={() => setCurrency('INR')}
                className={`px-2.5 py-1 rounded-lg font-bold transition-colors ${
                  currency === 'INR' ? 'bg-amber-500 text-stone-950' : 'text-[#cfbfab] hover:text-white'
                }`}
              >
                ₹ INR
              </button>
              <button
                onClick={() => setCurrency('USD')}
                className={`px-2.5 py-1 rounded-lg font-bold transition-colors ${
                  currency === 'USD' ? 'bg-amber-500 text-stone-950' : 'text-[#cfbfab] hover:text-white'
                }`}
              >
                $ USD
              </button>
            </div>
          </div>

          {/* Category Tabs Strip */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-2 scrollbar-none">
            {MENU_CATEGORIES.map((cat) => {
              const Icon = CATEGORY_ICONS[cat.id] || UtensilsCrossed;
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  id={`cat-tab-${cat.id}`}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all shrink-0 ${
                    isActive
                      ? 'bg-amber-500 text-stone-950 font-bold shadow-lg shadow-amber-950/50'
                      : 'bg-[#221811] text-[#d6c4ad] border border-[#3b2a1c] hover:bg-[#2e2016]'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-stone-950' : 'text-amber-400'}`} />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Menu Items Grid */}
        {filteredItems.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-[#19120d] border border-[#36271b] space-y-3">
            <UtensilsCrossed className="w-10 h-10 text-amber-500/60 mx-auto" />
            <h3 className="text-lg font-serif font-bold text-[#f5eedb]">No dishes match your selection</h3>
            <p className="text-xs text-[#9c8975] max-w-sm mx-auto">
              Try searching with another keyword, clearing the dietary filter, or selecting "All Delicacies".
            </p>
            <button
              onClick={() => {
                setActiveCategory('all');
                setDietaryFilter('all');
                setSearchQuery('');
              }}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-amber-500 text-stone-950 hover:bg-amber-400"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => {
              const qtyInCart = cart[item.id] || 0;

              return (
                <div
                  key={item.id}
                  id={`menu-card-${item.id}`}
                  className="rounded-2xl bg-[#1a130e] border border-[#362619] hover:border-amber-700/60 transition-all duration-300 overflow-hidden flex flex-col group shadow-lg hover:shadow-2xl hover:shadow-amber-950/30"
                >
                  {/* Dish Image + Badges */}
                  <div className="relative h-48 overflow-hidden bg-black/40">
                    <img
                      src={item.image}
                      alt={item.name}
                      loading="lazy"
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#1a130e] via-transparent to-black/40" />

                    {/* Dietary Marker (Veg/Non-Veg) */}
                    <div className="absolute top-3 left-3 flex items-center gap-1.5">
                      {item.dietary === 'veg' ? (
                        <div className="w-6 h-6 rounded bg-white flex items-center justify-center shadow-md" title="Pure Vegetarian">
                          <div className="w-2.5 h-2.5 rounded-full bg-emerald-600"></div>
                        </div>
                      ) : (
                        <div className="w-6 h-6 rounded bg-white flex items-center justify-center shadow-md" title="Non-Vegetarian (100% Halal)">
                          <div className="w-2.5 h-2.5 rounded-sm bg-red-600 rotate-45"></div>
                        </div>
                      )}

                      {item.isChefSpecial && (
                        <span className="px-2 py-0.5 rounded-full bg-amber-500 text-stone-950 text-[10px] font-bold tracking-wide flex items-center gap-1 shadow-md">
                          <Crown className="w-3 h-3" /> Chef's Signature
                        </span>
                      )}
                    </div>

                    {/* Portion Size Tag */}
                    {item.portionSize && (
                      <div className="absolute bottom-2 left-3 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-sm text-[10px] text-amber-200 border border-amber-900/30">
                        {item.portionSize}
                      </div>
                    )}
                  </div>

                  {/* Dish Details */}
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                    <div className="space-y-1.5">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-serif font-bold text-lg text-[#fffdf7] group-hover:text-amber-300 transition-colors">
                          {item.name}
                        </h3>
                        <span className="font-serif font-bold text-lg text-amber-400 shrink-0">
                          {formatPrice(item.price)}
                        </span>
                      </div>

                      {item.hindiName && (
                        <div className="text-xs text-amber-400/80 font-medium">
                          {item.hindiName}
                        </div>
                      )}

                      <p className="text-xs text-[#b8a691] line-clamp-2 leading-relaxed">
                        {item.description}
                      </p>
                    </div>

                    {/* Card Footer: Spicy Indicator & Action Buttons */}
                    <div className="pt-3 border-t border-[#2e2015] flex items-center justify-between">
                      {/* Spice Level meter */}
                      <div className="flex items-center gap-1" title={`Spice Level: ${item.spiceLevel} / 3`}>
                        <span className="text-[10px] text-[#8e7a67] mr-1">Spice:</span>
                        {item.spiceLevel === 0 ? (
                          <span className="text-[11px] text-emerald-400 font-medium">Mild</span>
                        ) : (
                          Array.from({ length: 3 }).map((_, idx) => (
                            <Flame
                              key={idx}
                              className={`w-3.5 h-3.5 ${
                                idx < item.spiceLevel ? 'text-amber-500 fill-amber-500' : 'text-[#3e2c1e]'
                              }`}
                            />
                          ))
                        )}
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-2">
                        <button
                          id={`dish-info-btn-${item.id}`}
                          onClick={() => setSelectedDishForModal(item)}
                          className="p-1.5 rounded-lg text-[#9c8975] hover:text-amber-300 hover:bg-[#2c1d13] transition-colors"
                          title="View dish details & allergens"
                        >
                          <Info className="w-4 h-4" />
                        </button>

                        {qtyInCart === 0 ? (
                          <button
                            id={`add-platter-btn-${item.id}`}
                            onClick={() => onAddToCart(item)}
                            className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add to Platter</span>
                          </button>
                        ) : (
                          <div className="flex items-center bg-amber-500/15 border border-amber-500/40 rounded-lg p-0.5">
                            <button
                              id={`minus-qty-btn-${item.id}`}
                              onClick={() => onUpdateCartQty(item.id, -1)}
                              className="w-6 h-6 rounded flex items-center justify-center text-amber-300 hover:bg-amber-500 hover:text-stone-950 transition-colors"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2 text-xs font-bold text-amber-300">
                              {qtyInCart}
                            </span>
                            <button
                              id={`plus-qty-btn-${item.id}`}
                              onClick={() => onUpdateCartQty(item.id, 1)}
                              className="w-6 h-6 rounded flex items-center justify-center text-amber-300 hover:bg-amber-500 hover:text-stone-950 transition-colors"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Floating Platter Quick Action Banner when items added */}
        {totalCartCount > 0 && (
          <div className="sticky bottom-6 z-30 max-w-xl mx-auto p-4 rounded-2xl bg-gradient-to-r from-[#291b10] to-[#1f140c] border border-amber-500/40 shadow-2xl backdrop-blur-md flex items-center justify-between animate-fade-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-bold">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">
                  {totalCartCount} {totalCartCount === 1 ? 'Dish' : 'Dishes'} in Your Platter
                </h4>
                <p className="text-xs text-amber-300/80">Ready for instant dine-in pre-order or takeaway</p>
              </div>
            </div>
            <button
              id="sticky-view-platter-btn"
              onClick={onOpenCart}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs shadow-lg flex items-center gap-1.5 active:scale-95 transition-all"
            >
              <span>View Platter</span>
            </button>
          </div>
        )}

        {/* Dish Details Modal */}
        {selectedDishForModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
            <div className="relative w-full max-w-lg rounded-2xl bg-[#1b130e] border border-amber-600/40 shadow-2xl overflow-hidden text-left">
              <button
                id="close-dish-modal-btn"
                onClick={() => setSelectedDishForModal(null)}
                className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/60 text-white hover:bg-black/90 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="relative h-56 w-full">
                <img
                  src={selectedDishForModal.image}
                  alt={selectedDishForModal.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1b130e] via-transparent to-transparent" />
              </div>

              <div className="p-6 space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-serif font-bold text-2xl text-white">
                      {selectedDishForModal.name}
                    </h3>
                    {selectedDishForModal.hindiName && (
                      <div className="text-sm text-amber-400 font-medium">
                        {selectedDishForModal.hindiName}
                      </div>
                    )}
                  </div>
                  <div className="font-serif font-bold text-2xl text-amber-400">
                    {formatPrice(selectedDishForModal.price)}
                  </div>
                </div>

                <p className="text-sm text-[#d4c3ad] leading-relaxed">
                  {selectedDishForModal.description}
                </p>

                <div className="grid grid-cols-2 gap-3 pt-2 text-xs">
                  <div className="p-3 rounded-xl bg-[#241a12] border border-[#3b2a1c]">
                    <span className="text-[#8e7a67] block mb-1">Serving Size</span>
                    <span className="font-semibold text-white">{selectedDishForModal.portionSize || 'Individual / Sharing'}</span>
                  </div>

                  <div className="p-3 rounded-xl bg-[#241a12] border border-[#3b2a1c]">
                    <span className="text-[#8e7a67] block mb-1">Dietary Spec</span>
                    <span className="font-semibold text-white capitalize">
                      {selectedDishForModal.dietary === 'veg' ? '100% Pure Vegetarian' : 'Non-Vegetarian (Certified Halal)'}
                    </span>
                  </div>
                </div>

                {selectedDishForModal.allergens && selectedDishForModal.allergens.length > 0 && (
                  <div className="p-3 rounded-xl bg-[#241a12] border border-[#3b2a1c] text-xs">
                    <span className="text-[#8e7a67] block mb-1">Allergen Notice</span>
                    <span className="text-amber-300 font-medium">
                      Contains: {selectedDishForModal.allergens.join(', ')}
                    </span>
                  </div>
                )}

                <div className="pt-3 flex gap-3">
                  <button
                    id="modal-add-to-cart-btn"
                    onClick={() => {
                      onAddToCart(selectedDishForModal);
                      setSelectedDishForModal(null);
                    }}
                    className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add to Platter ({formatPrice(selectedDishForModal.price)})</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
