import React, { useState, useEffect } from 'react';
import { Camera, Maximize2, X, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';
import { GALLERY_IMAGES, GALLERY_CATEGORIES } from '../data/galleryData';
import { GalleryImage } from '../types';

export const PhotoGallery: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeImageIndex, setActiveImageIndex] = useState<number | null>(null);

  const filteredImages = GALLERY_IMAGES.filter((img) =>
    selectedCategory === 'all' ? true : img.category === selectedCategory
  );

  const activeImage = activeImageIndex !== null ? filteredImages[activeImageIndex] : null;

  const handleNext = () => {
    if (activeImageIndex !== null) {
      setActiveImageIndex((activeImageIndex + 1) % filteredImages.length);
    }
  };

  const handlePrev = () => {
    if (activeImageIndex !== null) {
      setActiveImageIndex((activeImageIndex - 1 + filteredImages.length) % filteredImages.length);
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (activeImageIndex === null) return;
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
      if (e.key === 'Escape') setActiveImageIndex(null);
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeImageIndex, filteredImages.length]);

  return (
    <section id="gallery" className="py-20 px-4 lg:px-8 bg-[#130e0a] relative">
      <div className="max-w-7xl mx-auto space-y-10">
        {/* Section Header */}
        <div className="text-center space-y-3 max-w-3xl mx-auto">
          <span className="text-amber-400 text-xs sm:text-sm font-semibold tracking-widest uppercase flex items-center justify-center gap-1.5">
            <Camera className="w-4 h-4" />
            Visual Feast & Ambiance
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#fffdf7]">
            Photo Gallery
          </h2>
          <p className="text-[#c9b7a0] text-sm sm:text-base leading-relaxed">
            Take a visual tour through our live charcoal tandoor, royal Mughal diwan halls, sizzling handis, and joyous family celebrations in Agra.
          </p>
        </div>

        {/* Category Filter Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          {GALLERY_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              id={`gallery-filter-${cat.id}`}
              onClick={() => {
                setSelectedCategory(cat.id);
                setActiveImageIndex(null);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                selectedCategory === cat.id
                  ? 'bg-amber-500 text-stone-950 font-bold shadow-lg shadow-amber-950/60'
                  : 'bg-[#201710] text-[#c9b8a3] border border-[#3d2b1d] hover:bg-[#2d2016]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Image Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredImages.map((img, index) => (
            <div
              key={img.id}
              id={`gallery-item-${img.id}`}
              onClick={() => setActiveImageIndex(index)}
              className="group relative h-72 rounded-2xl overflow-hidden cursor-pointer border border-[#3b2b1d] bg-[#1a120c] shadow-lg hover:border-amber-600/70 transition-all duration-300"
            >
              <img
                src={img.url}
                alt={img.title}
                loading="lazy"
                className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 filter brightness-90 group-hover:brightness-100"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

              {/* Hover Overlay Content */}
              <div className="absolute inset-0 p-5 flex flex-col justify-between">
                <div className="self-end p-2 rounded-full bg-black/50 text-white backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity transform group-hover:scale-105">
                  <Maximize2 className="w-4 h-4 text-amber-400" />
                </div>

                <div className="space-y-1 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                  <span className="text-[10px] tracking-wider uppercase text-amber-400 font-semibold block">
                    {img.category}
                  </span>
                  <h3 className="font-serif font-bold text-base text-white">
                    {img.title}
                  </h3>
                  <p className="text-xs text-[#cfbfab] line-clamp-2">
                    {img.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Fullscreen Lightbox Modal */}
        {activeImage && activeImageIndex !== null && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-md animate-fade-in">
            {/* Close Button */}
            <button
              id="lightbox-close-btn"
              onClick={() => setActiveImageIndex(null)}
              className="absolute top-5 right-5 z-20 p-2.5 rounded-full bg-[#241a12]/80 text-white hover:bg-amber-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Previous Button */}
            <button
              id="lightbox-prev-btn"
              onClick={handlePrev}
              className="absolute left-4 z-20 p-3 rounded-full bg-[#241a12]/80 text-white hover:bg-amber-600 transition-colors"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            {/* Next Button */}
            <button
              id="lightbox-next-btn"
              onClick={handleNext}
              className="absolute right-4 z-20 p-3 rounded-full bg-[#241a12]/80 text-white hover:bg-amber-600 transition-colors"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Image Container */}
            <div className="max-w-4xl max-h-[85vh] flex flex-col rounded-2xl overflow-hidden bg-[#1a120c] border border-amber-900/50 shadow-2xl">
              <div className="relative max-h-[65vh] overflow-hidden bg-black flex items-center justify-center">
                <img
                  src={activeImage.url}
                  alt={activeImage.title}
                  className="max-h-[65vh] w-auto object-contain"
                />
              </div>
              <div className="p-5 sm:p-6 bg-[#1f150e] flex justify-between items-center border-t border-[#3b2b1d]">
                <div className="space-y-1 max-w-xl">
                  <h3 className="font-serif font-bold text-lg text-white">
                    {activeImage.title}
                  </h3>
                  <p className="text-xs text-[#cfbeaa]">
                    {activeImage.description}
                  </p>
                </div>
                <div className="text-xs font-mono text-amber-400 shrink-0 pl-4">
                  {activeImageIndex + 1} / {filteredImages.length}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
