import React, { useState } from 'react';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  MessageSquare, 
  Send, 
  Navigation, 
  CheckCircle2, 
  Accessibility, 
  Car, 
  Baby, 
  Wifi, 
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantInfo';

export const ContactSection: React.FC = () => {
  const [inquiryName, setInquiryName] = useState('');
  const [inquiryPhone, setInquiryPhone] = useState('');
  const [inquiryEmail, setInquiryEmail] = useState('');
  const [inquirySubject, setInquirySubject] = useState('tour-group');
  const [inquiryMessage, setInquiryMessage] = useState('');
  const [inquirySent, setInquirySent] = useState(false);

  // Live status: checks whether restaurant is currently in lunch or dinner hours
  const isCurrentlyOpen = () => {
    const now = new Date();
    const currentHour = now.getHours() + now.getMinutes() / 60;
    // Lunch: 12:00 to 16:00, Dinner: 19:00 to 23.5
    const isLunch = currentHour >= 12 && currentHour < 16;
    const isDinner = currentHour >= 19 && currentHour < 23.5;
    return isLunch || isDinner;
  };

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiryName.trim() || !inquiryPhone.trim()) return;

    setInquirySent(true);
  };

  return (
    <section id="contact" className="py-20 px-4 lg:px-8 bg-[#120e0b] relative">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Section Header */}
        <div className="text-center space-y-3 max-w-3xl mx-auto">
          <span className="text-amber-400 text-xs sm:text-sm font-semibold tracking-widest uppercase flex items-center justify-center gap-1.5">
            <Navigation className="w-4 h-4" />
            Seamless Accessibility & Location
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#fffdf7]">
            Find & Contact Us in Agra
          </h2>
          <p className="text-[#c9b7a0] text-sm sm:text-base leading-relaxed">
            Conveniently located 500 meters from the Taj Mahal East Gate parking terminal, with dedicated coach parking, step-free wheelchair access, and warm hospitality.
          </p>
        </div>

        {/* Live Status & Quick Action Callout */}
        <div className="max-w-4xl mx-auto p-4 rounded-2xl bg-[#1c140d] border border-amber-800/40 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
          <div className="flex items-center gap-3">
            <span className="relative flex h-3.5 w-3.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500"></span>
            </span>
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Restaurant Status:</span>
                <span className="text-emerald-400 font-semibold">
                  {isCurrentlyOpen() ? 'Open Now (Serving Fresh)' : 'Currently Open (Lunch & Dinner)'}
                </span>
              </h4>
              <p className="text-xs text-[#a89580]">Lunch: 12 PM - 4 PM • Dinner: 7 PM - 11:30 PM • 7 Days a Week</p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <a
              id="quick-call-cta"
              href={`tel:${RESTAURANT_INFO.phone.primary}`}
              className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-colors"
            >
              <Phone className="w-4 h-4" />
              <span>Call Reception</span>
            </a>
            <a
              id="quick-whatsapp-cta"
              href={RESTAURANT_INFO.phone.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-colors"
            >
              <MessageSquare className="w-4 h-4" />
              <span>WhatsApp Us</span>
            </a>
          </div>
        </div>

        {/* Contact Grid: Details, Map, and Inquiry Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Address, Phones, Timing Cards */}
          <div className="lg:col-span-5 space-y-6">
            {/* Address Card */}
            <div className="p-6 rounded-2xl bg-[#1a130e] border border-[#3b2a1c] space-y-3 shadow-xl">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <h3 className="font-serif font-bold text-base text-white">Physical Location</h3>
                  <p className="text-xs text-[#d1c2ae] leading-relaxed">
                    <strong>{RESTAURANT_INFO.name}</strong><br />
                    {RESTAURANT_INFO.address.street},<br />
                    {RESTAURANT_INFO.address.city}, {RESTAURANT_INFO.address.state} - {RESTAURANT_INFO.address.pincode}, {RESTAURANT_INFO.address.country}
                  </p>
                  <p className="text-xs text-amber-400/90 font-medium pt-1">
                    Landmark: {RESTAURANT_INFO.address.landmark}
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <a
                  id="google-maps-directions-link"
                  href={`https://maps.google.com/?q=${encodeURIComponent('Taj East Gate Road Agra Shilpgram')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-xs font-semibold text-amber-400 hover:text-amber-300 underline"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Open Directions in Google Maps</span>
                </a>
              </div>
            </div>

            {/* Direct Communication Channels */}
            <div className="p-6 rounded-2xl bg-[#1a130e] border border-[#3b2a1c] space-y-4 shadow-xl">
              <h3 className="font-serif font-bold text-base text-white flex items-center gap-2">
                <Phone className="w-4 h-4 text-amber-400" />
                <span>Direct Contact Numbers</span>
              </h3>

              <div className="space-y-2.5 text-xs">
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#241a12] border border-[#38281a]">
                  <div>
                    <span className="text-[#8f7d6a] block">Primary Line & Table Booking</span>
                    <strong className="text-white text-sm">{RESTAURANT_INFO.phone.primary}</strong>
                  </div>
                  <a
                    href={`tel:${RESTAURANT_INFO.phone.primary}`}
                    className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold"
                  >
                    Call
                  </a>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#241a12] border border-[#38281a]">
                  <div>
                    <span className="text-[#8f7d6a] block">Reception & Banquet Enquiries</span>
                    <strong className="text-white text-sm">{RESTAURANT_INFO.phone.secondary}</strong>
                  </div>
                  <a
                    href={`tel:${RESTAURANT_INFO.phone.secondary}`}
                    className="px-3 py-1.5 rounded-lg bg-[#36271a] hover:bg-amber-500 hover:text-stone-950 text-amber-300 font-bold transition-colors"
                  >
                    Call
                  </a>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#241a12] border border-[#38281a]">
                  <div>
                    <span className="text-[#8f7d6a] block">Official Email Address</span>
                    <strong className="text-white">{RESTAURANT_INFO.email}</strong>
                  </div>
                  <a
                    href={`mailto:${RESTAURANT_INFO.email}`}
                    className="px-3 py-1.5 rounded-lg bg-[#36271a] hover:bg-amber-500 hover:text-stone-950 text-amber-300 font-bold transition-colors"
                  >
                    Email
                  </a>
                </div>
              </div>
            </div>

            {/* Accessibility Features Badge List */}
            <div className="p-6 rounded-2xl bg-[#1a130e] border border-[#3b2a1c] space-y-3 shadow-xl">
              <h3 className="font-serif font-bold text-base text-white flex items-center gap-2">
                <Accessibility className="w-4 h-4 text-amber-400" />
                <span>Accessibility & Amenities</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {RESTAURANT_INFO.accessibility.map((acc, i) => (
                  <div key={i} className="p-2.5 rounded-lg bg-[#22170f] border border-[#38271a] space-y-0.5">
                    <span className="text-amber-300 font-semibold block">{acc.label}</span>
                    <span className="text-[#8f7e6d] text-[11px] leading-tight block">{acc.desc}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Map Preview + Inquiry Form */}
          <div className="lg:col-span-7 space-y-6">
            {/* Interactive Map Frame */}
            <div className="rounded-2xl overflow-hidden border border-[#3b2a1c] bg-[#1a130e] shadow-xl space-y-3 p-4">
              <div className="flex justify-between items-center mb-1 px-1">
                <div>
                  <h4 className="font-serif font-bold text-sm text-white">Location Map & Directions</h4>
                  <p className="text-xs text-[#9e8b77]">East Gate Road, Shilpgram Hub, Agra</p>
                </div>
                <span className="text-xs text-amber-400 font-medium">500m from Taj Mahal East Gate</span>
              </div>

              <div className="relative w-full h-64 rounded-xl overflow-hidden border border-[#332316] bg-[#221811]">
                <iframe
                  title="Family Flavour Restaurant Agra Map"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14197.886361817452!2d78.0463!3d27.1706!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39747121d702ff6d%3A0xdd2ae4803f767dde!2sTaj%20Mahal%20East%20Gate!5e0!3m2!1sen!2sin!4v1700000000000"
                  className="w-full h-full border-0 filter invert-[90%] hue-rotate-180 contrast-90 brightness-90"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
                <div className="absolute top-3 left-3 px-3 py-1 rounded-lg bg-[#140e0a]/90 backdrop-blur-md border border-amber-600/40 text-xs text-white font-medium shadow-lg pointer-events-none">
                  📍 Family Flavour Restaurant • Agra
                </div>
              </div>
            </div>

            {/* Quick Contact / Tour Group / Banquet Inquiry Form */}
            <div className="p-6 sm:p-8 rounded-2xl bg-[#1a130e] border border-[#3b2a1c] shadow-xl space-y-6">
              <div className="space-y-1">
                <h3 className="font-serif font-bold text-xl text-white">
                  Send Us an Inquiry or Message
                </h3>
                <p className="text-xs text-[#ad9a86]">
                  Planning a large tour group banquet, private family room booking, or catering requirement? Drop a message below.
                </p>
              </div>

              {inquirySent ? (
                <div className="p-6 rounded-xl bg-[#231911] border border-emerald-500/50 text-center space-y-3 animate-fade-in">
                  <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
                  <h4 className="font-serif font-bold text-lg text-white">Message Received!</h4>
                  <p className="text-xs text-[#cfbfab] max-w-md mx-auto">
                    Thank you, {inquiryName}. Our restaurant manager will reach back to you at {inquiryPhone} within 2 hours.
                  </p>
                  <button
                    onClick={() => setInquirySent(false)}
                    className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs transition-colors"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleInquirySubmit} className="space-y-4 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="inquiry-name" className="block text-[#c4b19c] font-medium mb-1">
                        Your Name *
                      </label>
                      <input
                        id="inquiry-name"
                        type="text"
                        value={inquiryName}
                        onChange={(e) => setInquiryName(e.target.value)}
                        placeholder="e.g. Anand Mehra"
                        required
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#241a12] border border-[#483524] text-white placeholder-[#857260] focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label htmlFor="inquiry-phone" className="block text-[#c4b19c] font-medium mb-1">
                        Phone / WhatsApp Number *
                      </label>
                      <input
                        id="inquiry-phone"
                        type="tel"
                        value={inquiryPhone}
                        onChange={(e) => setInquiryPhone(e.target.value)}
                        placeholder="+91 98765 43210"
                        required
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#241a12] border border-[#483524] text-white placeholder-[#857260] focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="inquiry-email" className="block text-[#c4b19c] font-medium mb-1">
                        Email Address (Optional)
                      </label>
                      <input
                        id="inquiry-email"
                        type="email"
                        value={inquiryEmail}
                        onChange={(e) => setInquiryEmail(e.target.value)}
                        placeholder="anand@example.com"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#241a12] border border-[#483524] text-white placeholder-[#857260] focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label htmlFor="inquiry-subject" className="block text-[#c4b19c] font-medium mb-1">
                        Inquiry Topic
                      </label>
                      <select
                        id="inquiry-subject"
                        value={inquirySubject}
                        onChange={(e) => setInquirySubject(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#241a12] border border-[#483524] text-white focus:outline-none focus:border-amber-500"
                      >
                        <option value="tour-group">Tour Group / Travel Agency Banquet</option>
                        <option value="family-event">Private Family Gathering / Birthday</option>
                        <option value="dietary-inquiry">Specific Dietary or Allergen Question</option>
                        <option value="general-feedback">General Feedback & Assistance</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="inquiry-message" className="block text-[#c4b19c] font-medium mb-1">
                      Your Message or Requirement
                    </label>
                    <textarea
                      id="inquiry-message"
                      rows={3}
                      value={inquiryMessage}
                      onChange={(e) => setInquiryMessage(e.target.value)}
                      placeholder="Share guest count, preferred dates, or special culinary requests..."
                      className="w-full px-3.5 py-2 rounded-xl bg-[#241a12] border border-[#483524] text-white placeholder-[#857260] focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <button
                    id="submit-inquiry-btn"
                    type="submit"
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-bold text-xs shadow-lg transition-all flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>Send Message to Restaurant Manager</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
