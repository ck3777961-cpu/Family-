import React from 'react';
import { Star, MessageSquareQuote, CheckCircle, Sparkles } from 'lucide-react';
import { REVIEWS } from '../data/restaurantInfo';

export const Testimonials: React.FC = () => {
  return (
    <section id="testimonials" className="py-20 px-4 lg:px-8 bg-[#17100b] border-t border-b border-[#2d2015] relative">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <span className="text-amber-400 text-xs sm:text-sm font-semibold tracking-widest uppercase flex items-center justify-center gap-1.5">
            <Sparkles className="w-4 h-4" />
            Loved By Families & Travelers
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#fffdf7]">
            Guest Impressions & Stories
          </h2>
          <p className="text-[#c7b59e] text-sm sm:text-base">
            From local family celebrations to travelers from around the world visiting the Taj Mahal, here is what our guests have to say.
          </p>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {REVIEWS.map((review) => (
            <div
              key={review.id}
              className="p-6 rounded-2xl bg-[#1f150e] border border-[#3b2b1d] shadow-xl flex flex-col justify-between space-y-4 hover:border-amber-700/50 transition-colors"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    {Array.from({ length: review.rating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-amber-400 fill-amber-400" />
                    ))}
                  </div>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#2a1d13] text-amber-300 border border-amber-900/30 font-medium">
                    {review.source}
                  </span>
                </div>

                <p className="text-sm text-[#ddd0bd] italic leading-relaxed">
                  "{review.comment}"
                </p>
              </div>

              <div className="pt-3 border-t border-[#312316] flex items-center justify-between">
                <div>
                  <h4 className="font-serif font-bold text-sm text-white">{review.author}</h4>
                  <span className="text-xs text-[#8f7d6a]">{review.location} • {review.date}</span>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-[#8f7d6a] block">Favorite Dish</span>
                  <span className="text-xs font-semibold text-amber-400">{review.highlightDish}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Accreditation Banner */}
        <div className="p-6 rounded-2xl bg-[#22170f] border border-amber-900/40 text-center max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-around gap-6">
          <div className="space-y-1">
            <span className="font-serif text-3xl font-bold text-amber-400">4.9 ★</span>
            <p className="text-xs text-[#b09e89]">TripAdvisor Travelers’ Choice</p>
          </div>
          <div className="h-8 w-px bg-[#3b2b1d] hidden sm:block"></div>
          <div className="space-y-1">
            <span className="font-serif text-3xl font-bold text-amber-400">2,800+</span>
            <p className="text-xs text-[#b09e89]">Google 5-Star Reviews</p>
          </div>
          <div className="h-8 w-px bg-[#3b2b1d] hidden sm:block"></div>
          <div className="space-y-1">
            <span className="font-serif text-3xl font-bold text-amber-400">100%</span>
            <p className="text-xs text-[#b09e89]">Fresh Daily Preparation</p>
          </div>
        </div>
      </div>
    </section>
  );
};
