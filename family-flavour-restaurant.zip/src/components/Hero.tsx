import React from 'react';
import { Calendar, Utensils, Star, Award, ShieldCheck, HeartHandshake, ArrowRight, Clock, MapPin } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantInfo';

interface HeroProps {
  onExploreMenu: () => void;
  onBookTable: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreMenu, onBookTable }) => {
  return (
    <section id="hero" className="relative min-h-[90vh] flex items-center justify-center pt-28 pb-16 px-4 lg:px-8 overflow-hidden">
      {/* Background Image with Ambient Dark Golden Vignette */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=2000&q=85"
          alt="Family Flavour Restaurant Ambiance"
          className="w-full h-full object-cover object-center scale-105 transform filter brightness-40 contrast-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#120e0b] via-[#120e0b]/75 to-[#120e0b]/60" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-500/10 via-transparent to-transparent pointer-events-none" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto text-center space-y-8">
        {/* Heritage Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-950/80 border border-amber-500/30 text-amber-300 text-xs sm:text-sm font-medium shadow-xl backdrop-blur-sm animate-fade-in">
          <Award className="w-4 h-4 text-amber-400" />
          <span>Established 1998 • Honoring Authentic Royal Agra Cuisine</span>
          <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
          <span className="text-amber-200/90 font-semibold">Near Taj Mahal East Gate</span>
        </div>

        {/* Main Heading */}
        <div className="space-y-4">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight font-serif text-[#fffbf2] leading-[1.12]">
            Where Every Meal is a <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-amber-600">
              Celebration of Flavours
            </span>
          </h1>
          <p className="max-w-2xl mx-auto text-[#ded0bc] text-base sm:text-lg lg:text-xl font-normal leading-relaxed">
            Welcome to <strong className="text-amber-300 font-semibold">{RESTAURANT_INFO.name}</strong>. Immerse your family in authentic slow-simmered Awadhi gravies, charcoal-roasted kebabs, fragrant saffron biryanis, and warm hospitality just minutes from the Taj Mahal.
          </p>
        </div>

        {/* Primary Call-to-Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
          <button
            id="hero-book-table-btn"
            onClick={onBookTable}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-bold text-base shadow-xl shadow-amber-950/80 hover:shadow-amber-500/25 transition-all flex items-center justify-center gap-3 transform hover:-translate-y-0.5"
          >
            <Calendar className="w-5 h-5" />
            <span>Reserve a Family Table</span>
          </button>

          <button
            id="hero-explore-menu-btn"
            onClick={onExploreMenu}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-[#23180f]/90 hover:bg-[#342416] text-[#f7eedc] border border-amber-700/50 hover:border-amber-500/70 font-semibold text-base shadow-lg transition-all flex items-center justify-center gap-3 group"
          >
            <Utensils className="w-5 h-5 text-amber-400" />
            <span>Explore Online Menu</span>
            <ArrowRight className="w-4 h-4 text-amber-400 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Quick Trust Highlights & Accreditations */}
        <div className="pt-6 grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 max-w-4xl mx-auto text-left">
          <div className="p-3 sm:p-4 rounded-xl bg-[#1c140d]/80 border border-[#3b2b1d] backdrop-blur-sm">
            <div className="flex items-center gap-2 text-amber-400 mb-1">
              <Star className="w-4 h-4 fill-amber-400" />
              <span className="font-bold text-sm text-white">4.9 / 5.0 Rating</span>
            </div>
            <p className="text-xs text-[#b8a691]">Over 2,800+ happy family reviews on Google & TripAdvisor</p>
          </div>

          <div className="p-3 sm:p-4 rounded-xl bg-[#1c140d]/80 border border-[#3b2b1d] backdrop-blur-sm">
            <div className="flex items-center gap-2 text-amber-400 mb-1">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span className="font-bold text-sm text-white">100% Halal & Fresh</span>
            </div>
            <p className="text-xs text-[#b8a691]">Handpicked spices, organic ghee, separate veg kitchen</p>
          </div>

          <div className="p-3 sm:p-4 rounded-xl bg-[#1c140d]/80 border border-[#3b2b1d] backdrop-blur-sm">
            <div className="flex items-center gap-2 text-amber-400 mb-1">
              <HeartHandshake className="w-4 h-4 text-amber-400" />
              <span className="font-bold text-sm text-white">Family First</span>
            </div>
            <p className="text-xs text-[#b8a691]">Spacious booths, kid high-chairs, calm pleasant acoustic</p>
          </div>

          <div className="p-3 sm:p-4 rounded-xl bg-[#1c140d]/80 border border-[#3b2b1d] backdrop-blur-sm">
            <div className="flex items-center gap-2 text-amber-400 mb-1">
              <MapPin className="w-4 h-4 text-amber-400" />
              <span className="font-bold text-sm text-white">Prime Location</span>
            </div>
            <p className="text-xs text-[#b8a691]">Near Taj East Gate, free valet parking & easy coach access</p>
          </div>
        </div>
      </div>
    </section>
  );
};
