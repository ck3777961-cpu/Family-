import React, { useState, useEffect } from 'react';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Users, 
  Sparkles, 
  CheckCircle, 
  ShieldCheck, 
  Phone, 
  Mail, 
  User, 
  PartyPopper, 
  HeartHandshake, 
  MapPin, 
  Share2, 
  Download,
  AlertCircle,
  X
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ReservationDetails } from '../types';
import { RESTAURANT_INFO } from '../data/restaurantInfo';

const LUNCH_SLOTS = ['12:00 PM', '12:30 PM', '1:00 PM', '1:30 PM', '2:00 PM', '2:30 PM', '3:00 PM'];
const DINNER_SLOTS = ['7:00 PM', '7:30 PM', '8:00 PM', '8:30 PM', '9:00 PM', '9:30 PM', '10:00 PM'];

const SEATING_AREAS = [
  { id: 'family-hall', label: 'Royal Diwan Hall', desc: 'Central spacious hall with ornate arches, ideal for lively family get-togethers' },
  { id: 'candlelight-alcove', label: 'Candlelight Booth', desc: 'Cozy private booth with warm lighting, perfect for anniversaries & couples' },
  { id: 'garden-terrace', label: 'Veranda Terrace', desc: 'Pleasant semi-open air seating with fresh plants and evening breeze' },
  { id: 'first-available', label: 'First Available Priority Table', desc: 'We will seat you at the best available table upon your arrival' }
] as const;

export const ReservationSystem: React.FC = () => {
  // Today's date formatted as YYYY-MM-DD
  const getTodayString = () => new Date().toISOString().split('T')[0];

  const [date, setDate] = useState<string>(getTodayString());
  const [mealType, setMealType] = useState<'lunch' | 'dinner'>('dinner');
  const [timeSlot, setTimeSlot] = useState<string>('8:00 PM');
  const [guestsCount, setGuestsCount] = useState<number>(4);
  const [seatingArea, setSeatingArea] = useState<ReservationDetails['seatingArea']>('family-hall');
  const [occasion, setOccasion] = useState<ReservationDetails['occasion']>('family-reunion');
  
  // Guest details
  const [guestName, setGuestName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');

  // Toggles for accessibility & dietary
  const [needHighChair, setNeedHighChair] = useState(false);
  const [needWheelchair, setNeedWheelchair] = useState(false);
  const [needJainFood, setNeedJainFood] = useState(false);
  const [needMildSpice, setNeedMildSpice] = useState(false);

  // Status & Saved reservations
  const [confirmedReservation, setConfirmedReservation] = useState<ReservationDetails | null>(null);
  const [pastReservations, setPastReservations] = useState<ReservationDetails[]>([]);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Load past reservations from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('family_flavour_reservations');
      if (saved) {
        setPastReservations(JSON.parse(saved));
      }
    } catch {
      // ignore
    }
  }, []);

  const handleTimeSlotChange = (slot: string) => {
    setTimeSlot(slot);
  };

  const handleMealTypeSwitch = (type: 'lunch' | 'dinner') => {
    setMealType(type);
    setTimeSlot(type === 'lunch' ? LUNCH_SLOTS[2] : DINNER_SLOTS[2]);
  };

  const handleSubmitBooking = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!guestName.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }
    if (!phone.trim() || phone.length < 8) {
      setErrorMessage('Please enter a valid phone number for confirmation SMS/WhatsApp.');
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      // Build special requests notes
      const notesList: string[] = [];
      if (needHighChair) notesList.push('Baby High Chair requested');
      if (needWheelchair) notesList.push('Wheelchair ramp assistance required');
      if (needJainFood) notesList.push('Jain vegetarian preparation');
      if (needMildSpice) notesList.push('Mild spices for children/guests');
      if (specialRequests.trim()) notesList.push(specialRequests.trim());

      const refCode = `FFR-${Math.floor(1000 + Math.random() * 9000)}`;

      const newReservation: ReservationDetails = {
        id: refCode,
        guestName: guestName.trim(),
        email: email.trim(),
        phone: phone.trim(),
        date,
        timeSlot,
        guestsCount,
        seatingArea,
        occasion,
        specialRequests: notesList.join(' | '),
        createdAt: new Date().toISOString(),
        status: 'confirmed'
      };

      // Save to state & localStorage
      const updatedList = [newReservation, ...pastReservations];
      setPastReservations(updatedList);
      try {
        localStorage.setItem('family_flavour_reservations', JSON.stringify(updatedList));
      } catch {
        // ignore
      }

      setConfirmedReservation(newReservation);
      setIsSubmitting(false);

      // Trigger festive celebration confetti
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#f59e0b', '#d97706', '#fbbf24', '#ffffff']
        });
      } catch {
        // ignore
      }
    }, 450);
  };

  const downloadIcsCalendar = (res: ReservationDetails) => {
    const calendarContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Family Flavour Restaurant//Table Reservation//EN',
      'BEGIN:VEVENT',
      `SUMMARY:Dinner Reservation at Family Flavour Restaurant (${res.id})`,
      `DESCRIPTION:Table reserved for ${res.guestsCount} guests under ${res.guestName}. Reference: ${res.id}. Phone: ${RESTAURANT_INFO.phone.primary}`,
      `LOCATION:${RESTAURANT_INFO.address.street}, ${RESTAURANT_INFO.address.city}, ${RESTAURANT_INFO.address.country}`,
      `DTSTART:${res.date.replace(/-/g, '')}T190000Z`,
      `DTEND:${res.date.replace(/-/g, '')}T210000Z`,
      'END:VEVENT',
      'END:VCALENDAR'
    ].join('\r\n');

    const blob = new Blob([calendarContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', `FamilyFlavour_Reservation_${res.id}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleShareWhatsApp = (res: ReservationDetails) => {
    const text = encodeURIComponent(
      `Hello Family Flavour Restaurant! Here are my table reservation details:\n` +
      `Reference ID: ${res.id}\n` +
      `Name: ${res.guestName}\n` +
      `Date: ${res.date}\n` +
      `Time: ${res.timeSlot}\n` +
      `Guests: ${res.guestsCount}\n` +
      `Seating: ${res.seatingArea}\n` +
      `Special Requests: ${res.specialRequests || 'None'}\n\n` +
      `Please keep our table ready!`
    );
    window.open(`https://wa.me/919837012345?text=${text}`, '_blank');
  };

  return (
    <section id="reservation" className="py-20 px-4 lg:px-8 bg-[#17100b] relative border-t border-[#2e2015]">
      <div className="max-w-5xl mx-auto space-y-10">
        {/* Section Header */}
        <div className="text-center space-y-3">
          <span className="text-amber-400 text-xs sm:text-sm font-semibold tracking-widest uppercase flex items-center justify-center gap-1.5">
            <CalendarIcon className="w-4 h-4" />
            Instant Real-Time Confirmation
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#fffbf2]">
            Reserve Your Family Dining Table
          </h2>
          <p className="text-[#c7b59e] text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
            Planning a celebration or a family lunch after touring the Taj Mahal? Guarantee your preferred seating with no advance payment needed.
          </p>
        </div>

        {/* Existing Bookings quick trigger banner if any */}
        {pastReservations.length > 0 && !confirmedReservation && (
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#231810] border border-amber-800/40 text-xs">
            <span className="text-[#dfd0bc] flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-amber-400" />
              You have {pastReservations.length} active reservation(s) on file.
            </span>
            <button
              id="view-saved-reservations-btn"
              onClick={() => setShowHistoryModal(true)}
              className="text-amber-300 hover:text-amber-200 underline font-semibold"
            >
              View / Manage My Bookings
            </button>
          </div>
        )}

        {/* Main Reservation Card */}
        {confirmedReservation ? (
          /* Confirmation State */
          <div className="p-6 sm:p-10 rounded-2xl bg-[#1d140e] border border-amber-500/50 shadow-2xl text-center space-y-6 animate-fade-in">
            <div className="w-16 h-16 rounded-full bg-amber-500/20 border-2 border-amber-500 text-amber-400 mx-auto flex items-center justify-center shadow-lg">
              <PartyPopper className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <span className="px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                Booking Confirmed
              </span>
              <h3 className="text-2xl sm:text-3xl font-serif font-bold text-white">
                We Look Forward to Welcoming You, {confirmedReservation.guestName}!
              </h3>
              <p className="text-xs sm:text-sm text-[#bcaaa5]">
                Your table is reserved. A confirmation copy and SMS notice have been scheduled.
              </p>
            </div>

            {/* Reference Badge Card */}
            <div className="max-w-md mx-auto p-5 rounded-xl bg-[#271b12] border border-amber-700/40 space-y-3 text-left">
              <div className="flex justify-between items-center border-b border-[#3b2b1d] pb-2.5">
                <span className="text-xs text-[#8f7d6a]">Reference Number</span>
                <span className="font-mono font-bold text-amber-400 text-lg tracking-wider">
                  {confirmedReservation.id}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-[#8f7d6a] block">Date</span>
                  <strong className="text-white">{confirmedReservation.date}</strong>
                </div>
                <div>
                  <span className="text-[#8f7d6a] block">Time Slot</span>
                  <strong className="text-white">{confirmedReservation.timeSlot}</strong>
                </div>
                <div>
                  <span className="text-[#8f7d6a] block">Guests Count</span>
                  <strong className="text-white">{confirmedReservation.guestsCount} Guests</strong>
                </div>
                <div>
                  <span className="text-[#8f7d6a] block">Seating</span>
                  <strong className="text-white capitalize">{confirmedReservation.seatingArea.replace('-', ' ')}</strong>
                </div>
              </div>

              {confirmedReservation.specialRequests && (
                <div className="pt-2 border-t border-[#3b2b1d] text-xs">
                  <span className="text-[#8f7d6a] block mb-0.5">Preferences & Notes</span>
                  <p className="text-amber-200">{confirmedReservation.specialRequests}</p>
                </div>
              )}
            </div>

            {/* Actions: Add to Calendar, WhatsApp Share, New Booking */}
            <div className="flex flex-wrap gap-3 justify-center pt-2">
              <button
                id="res-add-calendar-btn"
                onClick={() => downloadIcsCalendar(confirmedReservation)}
                className="px-4 py-2.5 rounded-xl bg-[#2c1e14] hover:bg-[#382619] border border-[#523924] text-xs font-semibold text-white flex items-center gap-2 transition-colors"
              >
                <Download className="w-4 h-4 text-amber-400" />
                <span>Save to Calendar (.ics)</span>
              </button>

              <button
                id="res-share-whatsapp-btn"
                onClick={() => handleShareWhatsApp(confirmedReservation)}
                className="px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-xs font-semibold text-white flex items-center gap-2 shadow-md transition-colors"
              >
                <Share2 className="w-4 h-4" />
                <span>Confirm on WhatsApp</span>
              </button>

              <button
                id="res-book-another-btn"
                onClick={() => setConfirmedReservation(null)}
                className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold transition-colors"
              >
                Book Another Table
              </button>
            </div>
          </div>
        ) : (
          /* Booking Form */
          <form
            onSubmit={handleSubmitBooking}
            className="p-6 sm:p-8 rounded-2xl bg-[#1d140e] border border-[#3b2a1c] shadow-2xl space-y-8"
          >
            {/* Step 1: Date & Meal Session */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-amber-400 text-sm font-serif font-bold">
                <span className="w-6 h-6 rounded-full bg-amber-500 text-stone-950 flex items-center justify-center text-xs font-sans">
                  1
                </span>
                <span>Select Date & Dining Time</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Date picker */}
                <div>
                  <label htmlFor="res-date-input" className="block text-xs font-medium text-[#c4b19c] mb-1.5">
                    Reservation Date
                  </label>
                  <div className="relative">
                    <input
                      id="res-date-input"
                      type="date"
                      min={getTodayString()}
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl bg-[#271b12] border border-[#4d3826] text-sm text-white focus:outline-none focus:border-amber-500 transition-colors"
                      required
                    />
                  </div>
                </div>

                {/* Lunch vs Dinner toggle */}
                <div>
                  <label className="block text-xs font-medium text-[#c4b19c] mb-1.5">
                    Dining Session
                  </label>
                  <div className="grid grid-cols-2 gap-2 bg-[#271b12] p-1 rounded-xl border border-[#4d3826]">
                    <button
                      type="button"
                      id="session-lunch-btn"
                      onClick={() => handleMealTypeSwitch('lunch')}
                      className={`py-1.5 rounded-lg text-xs font-bold transition-colors ${
                        mealType === 'lunch'
                          ? 'bg-amber-500 text-stone-950 shadow-md'
                          : 'text-[#cfbeab] hover:text-white'
                      }`}
                    >
                      Lunch (12 PM - 4 PM)
                    </button>
                    <button
                      type="button"
                      id="session-dinner-btn"
                      onClick={() => handleMealTypeSwitch('dinner')}
                      className={`py-1.5 rounded-lg text-xs font-bold transition-colors ${
                        mealType === 'dinner'
                          ? 'bg-amber-500 text-stone-950 shadow-md'
                          : 'text-[#cfbeab] hover:text-white'
                      }`}
                    >
                      Dinner (7 PM - 11:30 PM)
                    </button>
                  </div>
                </div>
              </div>

              {/* Time Slot Selector Pills */}
              <div>
                <label className="block text-xs font-medium text-[#c4b19c] mb-2">
                  Select Time Slot ({mealType === 'lunch' ? 'Lunch Service' : 'Dinner Service'})
                </label>
                <div className="flex flex-wrap gap-2">
                  {(mealType === 'lunch' ? LUNCH_SLOTS : DINNER_SLOTS).map((slot) => (
                    <button
                      key={slot}
                      type="button"
                      id={`time-slot-${slot.replace(/\s+/g, '-').toLowerCase()}`}
                      onClick={() => handleTimeSlotChange(slot)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                        timeSlot === slot
                          ? 'bg-amber-500 text-stone-950 font-bold shadow-md ring-2 ring-amber-400'
                          : 'bg-[#271b12] text-[#d1c0ae] border border-[#453120] hover:bg-[#342417]'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Step 2: Party Size & Seating Preference */}
            <div className="space-y-4 pt-4 border-t border-[#312316]">
              <div className="flex items-center gap-2 text-amber-400 text-sm font-serif font-bold">
                <span className="w-6 h-6 rounded-full bg-amber-500 text-stone-950 flex items-center justify-center text-xs font-sans">
                  2
                </span>
                <span>Number of Guests & Seating Preference</span>
              </div>

              {/* Guest Count Selector */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-xs font-medium text-[#c4b19c]">
                    Party Size: <strong className="text-amber-400 text-sm">{guestsCount} Guests</strong>
                  </label>
                  <span className="text-[11px] text-[#8e7b68]">Tables arranged together for larger families</span>
                </div>

                <div className="flex flex-wrap gap-2 items-center">
                  {[2, 4, 6, 8, 10, 12, 16].map((num) => (
                    <button
                      key={num}
                      type="button"
                      id={`guests-btn-${num}`}
                      onClick={() => setGuestsCount(num)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                        guestsCount === num
                          ? 'bg-amber-500 text-stone-950'
                          : 'bg-[#271b12] text-[#d6c4b2] border border-[#453120] hover:bg-[#342417]'
                      }`}
                    >
                      {num} People
                    </button>
                  ))}

                  {/* Manual +/- adjust */}
                  <div className="flex items-center bg-[#271b12] border border-[#453120] rounded-xl px-2 py-1 gap-2 text-xs text-white">
                    <span>Other:</span>
                    <button
                      type="button"
                      onClick={() => setGuestsCount(Math.max(1, guestsCount - 1))}
                      className="w-6 h-6 rounded bg-[#382618] hover:bg-amber-500 hover:text-stone-950 font-bold"
                    >
                      -
                    </button>
                    <span className="font-bold text-amber-400 min-w-[16px] text-center">{guestsCount}</span>
                    <button
                      type="button"
                      onClick={() => setGuestsCount(Math.min(40, guestsCount + 1))}
                      className="w-6 h-6 rounded bg-[#382618] hover:bg-amber-500 hover:text-stone-950 font-bold"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>

              {/* Seating Area Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                {SEATING_AREAS.map((area) => (
                  <button
                    key={area.id}
                    type="button"
                    id={`seating-${area.id}`}
                    onClick={() => setSeatingArea(area.id)}
                    className={`p-3.5 rounded-xl text-left transition-all border ${
                      seatingArea === area.id
                        ? 'bg-amber-950/60 border-amber-500 text-white shadow-lg'
                        : 'bg-[#241a12] border-[#402e1f] text-[#c9b7a2] hover:bg-[#2c1f15]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-serif font-bold text-sm text-amber-200">{area.label}</span>
                      {seatingArea === area.id && <CheckCircle className="w-4 h-4 text-amber-400 shrink-0" />}
                    </div>
                    <p className="text-xs text-[#9c8975] leading-normal">{area.desc}</p>
                  </button>
                ))}
              </div>

              {/* Occasion Selection */}
              <div>
                <label className="block text-xs font-medium text-[#c4b19c] mb-1.5">
                  Dining Occasion
                </label>
                <select
                  id="res-occasion-select"
                  value={occasion}
                  onChange={(e) => setOccasion(e.target.value as ReservationDetails['occasion'])}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#271b12] border border-[#4d3826] text-xs sm:text-sm text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="family-reunion">Family Feast / Reunion</option>
                  <option value="general">Casual Dinner / Lunch</option>
                  <option value="birthday">Birthday Celebration</option>
                  <option value="anniversary">Wedding Anniversary</option>
                  <option value="tourist-group">Tour / Travel Group Visit</option>
                  <option value="business-lunch">Business / Executive Meeting</option>
                </select>
              </div>
            </div>

            {/* Step 3: Special Accessibility & Dietary Needs */}
            <div className="space-y-3 pt-4 border-t border-[#312316]">
              <div className="flex items-center gap-2 text-amber-400 text-sm font-serif font-bold">
                <span className="w-6 h-6 rounded-full bg-amber-500 text-stone-950 flex items-center justify-center text-xs font-sans">
                  3
                </span>
                <span>Accessibility & Special Requests</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <label className="flex items-center gap-2.5 p-3 rounded-xl bg-[#241a12] border border-[#402e1f] cursor-pointer hover:bg-[#2b1f15]">
                  <input
                    type="checkbox"
                    checked={needHighChair}
                    onChange={(e) => setNeedHighChair(e.target.checked)}
                    className="accent-amber-500 w-4 h-4 rounded"
                  />
                  <span className="text-[#ded1c0]">Baby High Chair Required</span>
                </label>

                <label className="flex items-center gap-2.5 p-3 rounded-xl bg-[#241a12] border border-[#402e1f] cursor-pointer hover:bg-[#2b1f15]">
                  <input
                    type="checkbox"
                    checked={needWheelchair}
                    onChange={(e) => setNeedWheelchair(e.target.checked)}
                    className="accent-amber-500 w-4 h-4 rounded"
                  />
                  <span className="text-[#ded1c0]">Ground-floor Wheelchair Ramp Assistance</span>
                </label>

                <label className="flex items-center gap-2.5 p-3 rounded-xl bg-[#241a12] border border-[#402e1f] cursor-pointer hover:bg-[#2b1f15]">
                  <input
                    type="checkbox"
                    checked={needJainFood}
                    onChange={(e) => setNeedJainFood(e.target.checked)}
                    className="accent-amber-500 w-4 h-4 rounded"
                  />
                  <span className="text-[#ded1c0]">Jain Preparation (No Onion / Garlic)</span>
                </label>

                <label className="flex items-center gap-2.5 p-3 rounded-xl bg-[#241a12] border border-[#402e1f] cursor-pointer hover:bg-[#2b1f15]">
                  <input
                    type="checkbox"
                    checked={needMildSpice}
                    onChange={(e) => setNeedMildSpice(e.target.checked)}
                    className="accent-amber-500 w-4 h-4 rounded"
                  />
                  <span className="text-[#ded1c0]">Mild Spicing (For Children or Tourists)</span>
                </label>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#c4b19c] mb-1">
                  Additional Notes (e.g. cake celebration, quiet corner)
                </label>
                <textarea
                  id="res-notes-input"
                  rows={2}
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  placeholder="Any special requests or instructions for our restaurant team..."
                  className="w-full px-4 py-2 rounded-xl bg-[#271b12] border border-[#4d3826] text-xs text-white placeholder-[#857260] focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* Step 4: Contact Information */}
            <div className="space-y-4 pt-4 border-t border-[#312316]">
              <div className="flex items-center gap-2 text-amber-400 text-sm font-serif font-bold">
                <span className="w-6 h-6 rounded-full bg-amber-500 text-stone-950 flex items-center justify-center text-xs font-sans">
                  4
                </span>
                <span>Your Contact Details</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label htmlFor="res-name-input" className="block text-xs font-medium text-[#c4b19c] mb-1">
                    Full Name *
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-amber-500" />
                    <input
                      id="res-name-input"
                      type="text"
                      value={guestName}
                      onChange={(e) => setGuestName(e.target.value)}
                      placeholder="e.g. Ramesh Verma"
                      required
                      className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#271b12] border border-[#4d3826] text-xs sm:text-sm text-white placeholder-[#857260] focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="res-phone-input" className="block text-xs font-medium text-[#c4b19c] mb-1">
                    Mobile / WhatsApp Phone *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-amber-500" />
                    <input
                      id="res-phone-input"
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+91 98765 43210"
                      required
                      className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#271b12] border border-[#4d3826] text-xs sm:text-sm text-white placeholder-[#857260] focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="res-email-input" className="block text-xs font-medium text-[#c4b19c] mb-1">
                    Email Address (Optional)
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-amber-500" />
                    <input
                      id="res-email-input"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#271b12] border border-[#4d3826] text-xs sm:text-sm text-white placeholder-[#857260] focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
              </div>
            </div>

            {errorMessage && (
              <div className="p-3 rounded-xl bg-red-950/80 border border-red-500/50 text-xs text-red-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Submit CTA */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-xs text-[#a3917e]">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>No advance payment required. Table held for 20 mins past reserved time.</span>
              </div>

              <button
                id="submit-reservation-btn"
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-bold text-sm shadow-xl shadow-amber-950/70 transition-all active:scale-95 disabled:opacity-50"
              >
                {isSubmitting ? 'Confirming Your Table...' : 'Confirm Table Reservation'}
              </button>
            </div>
          </form>
        )}

        {/* Saved Bookings Modal */}
        {showHistoryModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
            <div className="w-full max-w-lg rounded-2xl bg-[#1d140e] border border-amber-600/40 p-6 space-y-4 shadow-2xl relative">
              <div className="flex justify-between items-center">
                <h3 className="font-serif font-bold text-lg text-white">Your Saved Reservations</h3>
                <button
                  onClick={() => setShowHistoryModal(false)}
                  className="p-1.5 rounded-lg text-stone-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                {pastReservations.map((res) => (
                  <div key={res.id} className="p-4 rounded-xl bg-[#271b12] border border-[#402e1f] space-y-2 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-mono font-bold text-amber-400">{res.id}</span>
                      <span className="text-emerald-400 font-semibold uppercase">{res.status}</span>
                    </div>
                    <div className="text-white font-medium">
                      {res.guestName} • {res.guestsCount} Guests
                    </div>
                    <div className="text-[#a3907c]">
                      Date: {res.date} at {res.timeSlot} ({res.seatingArea})
                    </div>
                  </div>
                ))}
              </div>

              <button
                onClick={() => setShowHistoryModal(false)}
                className="w-full py-2 rounded-xl bg-[#2e2015] hover:bg-[#3d2c1f] text-xs font-semibold text-white"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
