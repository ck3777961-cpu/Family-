import React from 'react';
import { Phone, Calendar, Utensils, MessageSquare, ShoppingBag } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantInfo';

interface QuickActionBarProps {
  onNavigate: (sectionId: string) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenReservation: () => void;
}

export const QuickActionBar: React.FC<QuickActionBarProps> = ({
  onNavigate,
  cartCount,
  onOpenCart,
  onOpenReservation
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 sm:hidden bg-[#160f0a]/95 backdrop-blur-md border-t border-[#3b2b1d] px-3 py-2 shadow-2xl">
      <div className="grid grid-cols-5 gap-1 text-center">
        {/* Call Button */}
        <a
          id="bar-call-btn"
          href={`tel:${RESTAURANT_INFO.phone.primary}`}
          className="flex flex-col items-center justify-center p-1 rounded-lg text-[#d1c2b0] hover:text-amber-400 active:bg-white/5"
        >
          <Phone className="w-4 h-4 text-amber-500 mb-0.5" />
          <span className="text-[10px] font-medium">Call</span>
        </a>

        {/* WhatsApp Button */}
        <a
          id="bar-whatsapp-btn"
          href={RESTAURANT_INFO.phone.whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center justify-center p-1 rounded-lg text-[#d1c2b0] hover:text-emerald-400 active:bg-white/5"
        >
          <MessageSquare className="w-4 h-4 text-emerald-400 mb-0.5" />
          <span className="text-[10px] font-medium">WhatsApp</span>
        </a>

        {/* Book Table Button (Center Highlight) */}
        <button
          id="bar-reserve-btn"
          onClick={onOpenReservation}
          className="flex flex-col items-center justify-center p-1 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-stone-950 font-bold -mt-3 shadow-lg shadow-amber-950/80 active:scale-95"
        >
          <Calendar className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] leading-tight">Book</span>
        </button>

        {/* Menu Button */}
        <button
          id="bar-menu-btn"
          onClick={() => onNavigate('menu')}
          className="flex flex-col items-center justify-center p-1 rounded-lg text-[#d1c2b0] hover:text-amber-400 active:bg-white/5"
        >
          <Utensils className="w-4 h-4 text-amber-500 mb-0.5" />
          <span className="text-[10px] font-medium">Menu</span>
        </button>

        {/* Taste Platter / Cart */}
        <button
          id="bar-platter-btn"
          onClick={onOpenCart}
          className="relative flex flex-col items-center justify-center p-1 rounded-lg text-[#d1c2b0] hover:text-amber-400 active:bg-white/5"
        >
          <ShoppingBag className="w-4 h-4 text-amber-500 mb-0.5" />
          <span className="text-[10px] font-medium">Platter</span>
          {cartCount > 0 && (
            <span className="absolute top-0 right-2 w-4 h-4 rounded-full bg-amber-500 text-stone-950 text-[10px] font-bold flex items-center justify-center">
              {cartCount}
            </span>
          )}
        </button>
      </div>
    </div>
  );
};
