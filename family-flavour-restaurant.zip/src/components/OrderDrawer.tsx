import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, Send, CheckCircle, Tag, Clock } from 'lucide-react';
import { MenuItem } from '../types';
import { MENU_ITEMS } from '../data/menuData';
import { RESTAURANT_INFO } from '../data/restaurantInfo';

interface OrderDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: { [itemId: string]: number };
  onUpdateQty: (itemId: string, delta: number) => void;
  onClearCart: () => void;
  onOpenReservation: () => void;
}

export const OrderDrawer: React.FC<OrderDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQty,
  onClearCart,
  onOpenReservation
}) => {
  const [orderType, setOrderType] = useState<'dine-in' | 'takeaway'>('dine-in');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [pickupTime, setPickupTime] = useState('Today, in 30 mins');
  const [specialInstructions, setSpecialInstructions] = useState('');
  const [discountCode, setDiscountCode] = useState('');
  const [discountApplied, setDiscountApplied] = useState(false);
  const [orderSubmitted, setOrderSubmitted] = useState(false);

  if (!isOpen) return null;

  // Retrieve item objects
  const cartItems = Object.entries(cart)
    .filter(([_, qty]) => Number(qty) > 0)
    .map(([id, qty]) => {
      const item = MENU_ITEMS.find((m) => m.id === id);
      return { item, qty: Number(qty) };
    })
    .filter((entry): entry is { item: MenuItem; qty: number } => Boolean(entry.item));

  const subtotal = cartItems.reduce((sum, entry) => sum + entry.item.price * entry.qty, 0);
  const discountAmount = discountApplied ? Math.round(subtotal * 0.1) : 0;
  const gstTax = Math.round((subtotal - discountAmount) * 0.05); // 5% GST on dining in India
  const finalTotal = subtotal - discountAmount + gstTax;

  const handleApplyCoupon = () => {
    if (discountCode.trim().toUpperCase() === 'FAMILY10' || discountCode.trim().toUpperCase() === 'TAJ10') {
      setDiscountApplied(true);
    } else {
      alert('Invalid coupon code. Try FAMILY10 for 10% off your family platter!');
    }
  };

  const handleSendWhatsAppOrder = () => {
    if (!customerName.trim() || !customerPhone.trim()) {
      alert('Please provide your name and phone number so we can prepare your order.');
      return;
    }

    const itemsSummary = cartItems
      .map((ci) => `• ${ci.qty}x ${ci.item.name} (₹${ci.item.price * ci.qty})`)
      .join('\n');

    const message = encodeURIComponent(
      `*New Platter Pre-Order from ${customerName}*\n` +
      `*Order Type:* ${orderType === 'dine-in' ? 'Dine-In Table Pre-Order' : 'Takeaway / Parcel'}\n` +
      `*Phone:* ${customerPhone}\n` +
      `*Time:* ${pickupTime}\n\n` +
      `*Items Requested:*\n${itemsSummary}\n\n` +
      `*Subtotal:* ₹${subtotal}\n` +
      (discountApplied ? `*Discount (FAMILY10):* -₹${discountAmount}\n` : '') +
      `*Estimated Total:* ₹${finalTotal}\n` +
      (specialInstructions ? `*Notes:* ${specialInstructions}\n\n` : '\n') +
      `Please confirm order availability!`
    );

    window.open(`https://wa.me/919837012345?text=${message}`, '_blank');
    setOrderSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fade-in">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#18110c] border-l border-[#3d2b1d] shadow-2xl flex flex-col justify-between text-left">
          {/* Drawer Header */}
          <div className="p-5 border-b border-[#362618] flex items-center justify-between bg-[#1f150e]">
            <div className="flex items-center gap-2.5">
              <ShoppingBag className="w-5 h-5 text-amber-400" />
              <div>
                <h3 className="font-serif font-bold text-base text-white">Your Taste Platter</h3>
                <span className="text-xs text-amber-300/80">
                  {cartItems.length} {cartItems.length === 1 ? 'variety' : 'varieties'} selected
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {cartItems.length > 0 && (
                <button
                  onClick={onClearCart}
                  className="p-1.5 rounded-lg text-stone-400 hover:text-red-400 transition-colors"
                  title="Clear entire platter"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg text-stone-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Drawer Body */}
          <div className="flex-1 overflow-y-auto p-5 space-y-5">
            {orderSubmitted ? (
              <div className="py-12 text-center space-y-4">
                <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500 text-emerald-400 flex items-center justify-center mx-auto">
                  <CheckCircle className="w-8 h-8" />
                </div>
                <h4 className="font-serif font-bold text-xl text-white">Platter Inquiry Sent!</h4>
                <p className="text-xs text-[#cfbfab] max-w-xs mx-auto">
                  Your meal summary has been initiated via WhatsApp. Our kitchen staff is reviewing the preparation time.
                </p>
                <div className="pt-2 flex flex-col gap-2">
                  <button
                    onClick={() => {
                      onClearCart();
                      setOrderSubmitted(false);
                      onClose();
                    }}
                    className="w-full py-2.5 rounded-xl bg-amber-500 text-stone-950 font-bold text-xs"
                  >
                    Done & Return to Website
                  </button>
                </div>
              </div>
            ) : cartItems.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <ShoppingBag className="w-12 h-12 text-[#5a432f] mx-auto" />
                <h4 className="font-serif font-bold text-base text-white">Your Platter is Empty</h4>
                <p className="text-xs text-[#9c8975] max-w-xs mx-auto">
                  Browse our Online Menu to select royal curries, fragrant biryanis, and artisan tandoori breads.
                </p>
                <button
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs transition-colors"
                >
                  Explore Menu Dishes
                </button>
              </div>
            ) : (
              <>
                {/* Order Type Selector */}
                <div className="grid grid-cols-2 gap-2 bg-[#22170f] p-1 rounded-xl border border-[#3b2a1c] text-xs">
                  <button
                    type="button"
                    onClick={() => setOrderType('dine-in')}
                    className={`py-2 rounded-lg font-bold transition-colors ${
                      orderType === 'dine-in' ? 'bg-amber-500 text-stone-950' : 'text-[#cfbeaa]'
                    }`}
                  >
                    Dine-In Pre-Order
                  </button>
                  <button
                    type="button"
                    onClick={() => setOrderType('takeaway')}
                    className={`py-2 rounded-lg font-bold transition-colors ${
                      orderType === 'takeaway' ? 'bg-amber-500 text-stone-950' : 'text-[#cfbeaa]'
                    }`}
                  >
                    Takeaway / Parcel
                  </button>
                </div>

                {/* Selected Dish List */}
                <div className="space-y-3">
                  {cartItems.map(({ item, qty }) => (
                    <div
                      key={item.id}
                      className="p-3 rounded-xl bg-[#20160f] border border-[#362618] flex items-center gap-3 text-xs"
                    >
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-14 h-14 rounded-lg object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-serif font-bold text-white truncate">{item.name}</h4>
                        <span className="text-amber-400 font-semibold">₹{item.price} each</span>
                        <div className="text-[10px] text-[#8c7a68] truncate">
                          Total: ₹{item.price * qty}
                        </div>
                      </div>

                      {/* Quantity Controller */}
                      <div className="flex items-center bg-[#2b1e15] rounded-lg border border-[#483422] p-1">
                        <button
                          onClick={() => onUpdateQty(item.id, -1)}
                          className="w-5 h-5 flex items-center justify-center text-amber-300 hover:text-white"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2 font-bold text-white">{qty}</span>
                        <button
                          onClick={() => onUpdateQty(item.id, 1)}
                          className="w-5 h-5 flex items-center justify-center text-amber-300 hover:text-white"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Coupon Code Input */}
                <div className="p-3 rounded-xl bg-[#22170f] border border-[#3b2a1c] space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[#a6937f] flex items-center gap-1">
                      <Tag className="w-3.5 h-3.5 text-amber-400" /> Have a Promo Code?
                    </span>
                    <span className="text-[10px] text-amber-400">Try code: <strong>FAMILY10</strong></span>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={discountCode}
                      onChange={(e) => setDiscountCode(e.target.value)}
                      placeholder="e.g. FAMILY10"
                      className="flex-1 px-3 py-1.5 rounded-lg bg-[#2b1e15] border border-[#483422] text-xs text-white uppercase placeholder-[#7a6857]"
                    />
                    <button
                      type="button"
                      onClick={handleApplyCoupon}
                      className="px-3 py-1.5 rounded-lg bg-[#3d2b1c] hover:bg-amber-500 hover:text-stone-950 text-amber-300 text-xs font-bold transition-colors"
                    >
                      Apply
                    </button>
                  </div>
                  {discountApplied && (
                    <span className="text-[11px] text-emerald-400 block">
                      ✓ 10% Family Discount Applied (-₹{discountAmount})
                    </span>
                  )}
                </div>

                {/* Guest Contact Details */}
                <div className="space-y-3 pt-2 text-xs">
                  <span className="font-serif font-bold text-white block">Your Details</span>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="Your Name *"
                      className="px-3 py-2 rounded-lg bg-[#22170f] border border-[#3b2a1c] text-white placeholder-[#7a6857]"
                    />
                    <input
                      type="tel"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="Phone Number *"
                      className="px-3 py-2 rounded-lg bg-[#22170f] border border-[#3b2a1c] text-white placeholder-[#7a6857]"
                    />
                  </div>
                  <input
                    type="text"
                    value={specialInstructions}
                    onChange={(e) => setSpecialInstructions(e.target.value)}
                    placeholder="Dietary instructions or spice notes..."
                    className="w-full px-3 py-2 rounded-lg bg-[#22170f] border border-[#3b2a1c] text-white placeholder-[#7a6857]"
                  />
                </div>
              </>
            )}
          </div>

          {/* Drawer Footer / Bill Summary */}
          {cartItems.length > 0 && !orderSubmitted && (
            <div className="p-5 bg-[#1f150e] border-t border-[#362618] space-y-3">
              <div className="space-y-1.5 text-xs text-[#bda994]">
                <div className="flex justify-between">
                  <span>Platter Subtotal</span>
                  <span className="text-white">₹{subtotal}</span>
                </div>
                {discountApplied && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Discount (FAMILY10)</span>
                    <span>-₹{discountAmount}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Restaurant GST (5%)</span>
                  <span className="text-white">₹{gstTax}</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-white border-t border-[#3b2a1c] pt-2">
                  <span>Estimated Total</span>
                  <span className="text-amber-400 font-serif text-lg">₹{finalTotal}</span>
                </div>
              </div>

              <div className="space-y-2 pt-1">
                <button
                  id="drawer-whatsapp-submit-btn"
                  onClick={handleSendWhatsAppOrder}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-bold text-xs shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Platter Order via WhatsApp</span>
                </button>

                {orderType === 'dine-in' && (
                  <button
                    onClick={() => {
                      onClose();
                      onOpenReservation();
                    }}
                    className="w-full py-2 rounded-xl bg-[#2c1d13] text-amber-300 hover:bg-[#3d2a1c] text-xs font-semibold"
                  >
                    Also Reserve a Table for this Meal
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
