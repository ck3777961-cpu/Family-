import React from 'react';
import { Utensils, Phone, Mail, MapPin, Clock, Heart, Award, ArrowUp } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantInfo';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#0e0a07] text-[#cfbeaa] border-t border-[#26190f] pt-16 pb-12 px-4 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand & Ethos */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center text-stone-950 font-bold">
                <Utensils className="w-5 h-5" />
              </div>
              <div>
                <span className="font-serif text-xl font-bold text-white block">Family Flavour</span>
                <span className="text-[10px] uppercase tracking-widest text-amber-400">Restaurant • Agra</span>
              </div>
            </div>

            <p className="text-xs text-[#a3907c] leading-relaxed">
              Serving the authentic heritage recipes of Agra, Awadh, and Punjab with pure ingredients, wood-fired tandoors, and generous family hospitality since 1998.
            </p>

            <div className="flex items-center gap-3 text-xs text-amber-400/90 font-medium">
              <Award className="w-4 h-4 text-amber-400" />
              <span>Certified 100% Halal & Pure Desi Ghee</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3 text-xs">
            <h4 className="font-serif font-bold text-sm text-white tracking-wide">Quick Navigation</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => onNavigate('hero')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Home & Welcoming
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('about')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Our Heritage & Kitchen Story
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('menu')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Royal Dining Menu
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('reservation')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Book a Table Online
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('gallery')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Photo Gallery & Ambiance
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Location & Contact Information
                </button>
              </li>
            </ul>
          </div>

          {/* Hours & Timings */}
          <div className="space-y-3 text-xs">
            <h4 className="font-serif font-bold text-sm text-white tracking-wide flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-amber-400" />
              <span>Service Hours</span>
            </h4>
            <div className="space-y-2 text-[#b09e8a]">
              <div>
                <span className="text-white block font-medium">Lunch Service</span>
                <span>{RESTAURANT_INFO.timings.lunch}</span>
              </div>
              <div>
                <span className="text-white block font-medium">Dinner Service</span>
                <span>{RESTAURANT_INFO.timings.dinner}</span>
              </div>
              <div className="text-amber-400/90 font-medium pt-1">
                {RESTAURANT_INFO.timings.days}
              </div>
              <div className="text-[11px] text-[#82715e]">
                {RESTAURANT_INFO.timings.tandoorHours}
              </div>
            </div>
          </div>

          {/* Contact Summary & Address */}
          <div className="space-y-3 text-xs">
            <h4 className="font-serif font-bold text-sm text-white tracking-wide flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-amber-400" />
              <span>Visit Us in Agra</span>
            </h4>
            <p className="text-[#a89582] leading-relaxed">
              {RESTAURANT_INFO.address.street}, {RESTAURANT_INFO.address.city}, {RESTAURANT_INFO.address.state}
            </p>
            <p className="text-[11px] text-amber-400/90 font-medium">
              Landmark: {RESTAURANT_INFO.address.landmark}
            </p>
            <div className="pt-2 space-y-1">
              <a
                href={`tel:${RESTAURANT_INFO.phone.primary}`}
                className="block text-white font-semibold hover:text-amber-300"
              >
                Phone: {RESTAURANT_INFO.phone.primary}
              </a>
              <a
                href={`mailto:${RESTAURANT_INFO.email}`}
                className="block text-[#a89582] hover:text-amber-300"
              >
                Email: {RESTAURANT_INFO.email}
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Strip */}
        <div className="pt-8 border-t border-[#1f140c] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#786653]">
          <div>
            © {new Date().getFullYear()} {RESTAURANT_INFO.name}. Inspired by the rich culinary tradition of Agra. All rights reserved.
          </div>

          <button
            id="back-to-top-btn"
            onClick={scrollToTop}
            className="flex items-center gap-1.5 text-amber-400 hover:text-amber-300 transition-colors"
          >
            <span>Back to Top</span>
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>
      </div>
    </footer>
  );
};
