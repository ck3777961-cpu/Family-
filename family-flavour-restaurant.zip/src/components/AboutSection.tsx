import React from 'react';
import { ChefHat, Flame, Sparkles, Heart, UtensilsCrossed, CheckCircle2 } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantInfo';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 px-4 lg:px-8 bg-[#16100c] border-t border-b border-[#2d2116] relative">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Visual Showcase Collage */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden border border-amber-900/40 shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1000&q=85"
                alt="Chef roasting kebabs over hot clay tandoor embers"
                className="w-full h-[420px] object-cover object-center filter brightness-90 hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              
              {/* Floating Chef Quote Overlay */}
              <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-[#1f150e]/90 border border-amber-500/30 backdrop-blur-md">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                    <ChefHat className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-serif font-bold text-white">Master Chef Ustad Nadeem Qureshi</h4>
                    <p className="text-xs text-amber-300/80">3rd Generation Awadhi & Tandoor Specialist</p>
                  </div>
                </div>
                <p className="mt-2 text-xs text-[#d3c2ab] italic">
                  "True flavour is never hurried. Our Dal Makhani rests for 24 hours on glowing embers to bring out that unforgettable smoky velvet texture."
                </p>
              </div>
            </div>

            {/* Experience Badge Pill */}
            <div className="hidden sm:flex absolute -top-5 -right-5 bg-gradient-to-br from-amber-500 to-amber-700 text-stone-950 font-bold p-4 rounded-2xl shadow-2xl flex-col items-center justify-center border-2 border-amber-300">
              <span className="text-3xl font-serif">25+</span>
              <span className="text-[11px] uppercase tracking-wider font-semibold">Years of Joy</span>
            </div>
          </div>

          {/* Right Column: Story & Principles */}
          <div className="lg:col-span-6 space-y-6">
            <div className="space-y-2">
              <span className="text-amber-400 text-xs sm:text-sm font-semibold tracking-wider uppercase flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                Our Story & Family Legacy
              </span>
              <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#fffdfa] leading-tight">
                Authentic Heritage Recipes Passed Down Through Generations
              </h2>
            </div>

            <p className="text-[#ded0bc] text-base leading-relaxed">
              Founded near the historic gates of the Taj Mahal in Agra, <strong className="text-amber-300 font-semibold">{RESTAURANT_INFO.name}</strong> was born out of a simple, enduring vision: to serve guests not merely food, but the genuine warmth and generosity of a traditional Indian family feast.
            </p>

            <p className="text-[#c7b59e] text-sm leading-relaxed">
              We reject modern commercial shortcuts. Our kitchen uses only whole spices roasted and ground in-house, stone-pressed mustard oils, pure dairy butter, and artisanal clay tandoor ovens ignited every dawn with seasoned wood and charcoal.
            </p>

            {/* 4 Pillars Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {RESTAURANT_INFO.features.map((feat, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-[#1f1610] border border-[#3b2b1d]">
                  <div className="flex items-center gap-2 text-amber-400 font-medium text-sm mb-1">
                    <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
                    <span className="text-white font-semibold">{feat.title}</span>
                  </div>
                  <p className="text-xs text-[#a8957f] leading-normal pl-6">{feat.desc}</p>
                </div>
              ))}
            </div>

            {/* Cultural Pride & Cleanliness Guarantee */}
            <div className="pt-2 flex flex-wrap items-center gap-6 text-xs text-[#cfbfab] border-t border-[#2d2116]">
              <div className="flex items-center gap-2">
                <Flame className="w-4 h-4 text-orange-400" />
                <span>Wood-Fired Clay Tandoor</span>
              </div>
              <div className="flex items-center gap-2">
                <Heart className="w-4 h-4 text-red-400" />
                <span>Dedicated Pure Veg & Jain Kitchen</span>
              </div>
              <div className="flex items-center gap-2">
                <UtensilsCrossed className="w-4 h-4 text-amber-400" />
                <span>Child-Friendly & Mild Options</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
