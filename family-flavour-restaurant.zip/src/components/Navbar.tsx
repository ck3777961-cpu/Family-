import React, { useState, useEffect } from 'react';
import { Phone, Calendar, Utensils, Clock, Menu, X, ShoppingBag, MapPin } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantInfo';

interface NavbarProps {
  activeSection: string;
  onNavigate: (sectionId: string) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenReservation: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeSection,
  onNavigate,
  cartCount,
  onOpenCart,
  onOpenReservation
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'hero', label: 'Home' },
    { id: 'about', label: 'Our Story' },
    { id: 'menu', label: 'Online Menu' },
    { id: 'reservation', label: 'Book a Table' },
    { id: 'gallery', label: 'Photo Gallery' },
    { id: 'testimonials', label: 'Reviews' },
    { id: 'contact', label: 'Contact & Location' }
  ];

  const handleLinkClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-300">
      {/* Top Announcements & Quick Info Bar */}
      <div className="bg-[#1c1510] text-[#d6c4a8] text-xs border-b border-[#3d2f22] py-1.5 px-4 hidden sm:block">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-6">
            <span className="flex items-center gap-1.5 text-[#e5b365]">
              <Clock className="w-3.5 h-3.5" />
              <span>Lunch: 12 PM - 4 PM | Dinner: 7 PM - 11:30 PM</span>
            </span>
            <span className="hidden md:flex items-center gap-1.5 text-[#bfa98d]">
              <MapPin className="w-3.5 h-3.5 text-[#d97706]" />
              <span>Taj East Gate Road, Agra • 500m from Monument Parking</span>
            </span>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-amber-400/90 font-medium">100% Halal & Pure Desi Ghee</span>
            <span className="text-[#5a4837]">|</span>
            <a
              id="topbar-phone-link"
              href={`tel:${RESTAURANT_INFO.phone.primary}`}
              className="flex items-center gap-1 hover:text-amber-300 transition-colors font-medium"
            >
              <Phone className="w-3 h-3 text-amber-500" />
              <span>{RESTAURANT_INFO.phone.primary}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <nav
        className={`px-4 lg:px-8 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#120e0b]/95 backdrop-blur-md shadow-2xl py-3 border-b border-[#362719]'
            : 'bg-gradient-to-b from-[#120e0b]/90 to-[#120e0b]/60 backdrop-blur-sm py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Logo */}
          <button
            id="brand-logo-btn"
            onClick={() => handleLinkClick('hero')}
            className="flex items-center gap-3 text-left group focus:outline-none"
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-900/40 border border-amber-300/30 group-hover:scale-105 transition-transform">
              <Utensils className="w-5 h-5 text-amber-950" />
            </div>
            <div>
              <span className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-white group-hover:text-amber-300 transition-colors flex items-center gap-1.5">
                Family Flavour
              </span>
              <span className="text-[10px] tracking-[0.2em] uppercase text-amber-400/80 font-medium block">
                Restaurant • Agra
              </span>
            </div>
          </button>

          {/* Desktop Links */}
          <div className="hidden lg:flex items-center space-x-1 xl:space-x-2">
            {navLinks.map((link) => (
              <button
                key={link.id}
                id={`nav-link-${link.id}`}
                onClick={() => handleLinkClick(link.id)}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                  activeSection === link.id
                    ? 'text-amber-400 bg-amber-950/40 border border-amber-800/40'
                    : 'text-[#e5dbc9] hover:text-amber-300 hover:bg-white/5'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* Action CTAs */}
          <div className="hidden sm:flex items-center space-x-3">
            {/* Platter / Order Cart Button */}
            <button
              id="navbar-cart-btn"
              onClick={onOpenCart}
              className="relative p-2.5 rounded-lg bg-[#241a12] border border-[#4d3925] text-amber-300 hover:bg-[#332418] hover:border-amber-600/50 transition-all flex items-center gap-2 text-sm"
              title="View Selected Dishes / Pre-Order"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden md:inline text-xs font-semibold text-[#f0e4d0]">Taste Platter</span>
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-amber-950 text-[11px] font-bold w-5 h-5 rounded-full flex items-center justify-center shadow-md">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Book a Table Primary Button */}
            <button
              id="navbar-reserve-btn"
              onClick={onOpenReservation}
              className="px-4 py-2 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-semibold text-sm shadow-lg shadow-amber-950/60 hover:shadow-amber-500/20 transition-all flex items-center gap-2 active:scale-95"
            >
              <Calendar className="w-4 h-4" />
              <span>Book a Table</span>
            </button>
          </div>

          {/* Mobile Menu & Cart Triggers */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              id="mobile-cart-btn"
              onClick={onOpenCart}
              className="relative p-2 rounded-lg bg-[#241a12] border border-[#4d3925] text-amber-300"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-500 text-amber-950 text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-[#241a12] border border-[#4d3925] text-[#f5eedb] hover:text-amber-300"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden mt-3 pt-3 border-t border-[#362719] bg-[#17110c] rounded-xl p-4 shadow-2xl space-y-2">
            {navLinks.map((link) => (
              <button
                key={link.id}
                id={`mobile-nav-link-${link.id}`}
                onClick={() => handleLinkClick(link.id)}
                className={`w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  activeSection === link.id
                    ? 'text-amber-400 bg-amber-950/60 border border-amber-800/40'
                    : 'text-[#e5dbc9] hover:bg-white/5'
                }`}
              >
                {link.label}
              </button>
            ))}

            <div className="pt-3 border-t border-[#2e2114] flex flex-col gap-2">
              <button
                id="mobile-reserve-btn-menu"
                onClick={() => {
                  onOpenReservation();
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 text-stone-950 font-bold text-sm flex items-center justify-center gap-2"
              >
                <Calendar className="w-4 h-4" />
                <span>Book Table Online</span>
              </button>
              <a
                id="mobile-call-btn-menu"
                href={`tel:${RESTAURANT_INFO.phone.primary}`}
                className="w-full py-2.5 rounded-lg bg-[#291e15] border border-[#4d3925] text-amber-300 font-medium text-sm flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4 text-amber-400" />
                <span>Call Us: {RESTAURANT_INFO.phone.primary}</span>
              </a>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};
