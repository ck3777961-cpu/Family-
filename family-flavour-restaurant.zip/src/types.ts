export type DietaryType = 'veg' | 'non-veg' | 'vegan';

export interface MenuItem {
  id: string;
  name: string;
  hindiName?: string;
  category: 'starters' | 'tandoor' | 'mains' | 'biryani' | 'breads' | 'thali' | 'desserts' | 'beverages';
  price: number;
  description: string;
  dietary: DietaryType;
  spiceLevel: 0 | 1 | 2 | 3; // 0=mild, 1=medium, 2=spicy, 3=extra spicy
  isChefSpecial?: boolean;
  isPopular?: boolean;
  isGlutenFree?: boolean;
  calories?: number;
  portionSize?: string;
  image: string;
  allergens?: string[];
}

export interface ReservationDetails {
  id: string;
  guestName: string;
  email: string;
  phone: string;
  date: string;
  timeSlot: string;
  guestsCount: number;
  seatingArea: 'royal-diwan' | 'family-hall' | 'candlelight-alcove' | 'garden-terrace' | 'first-available';
  occasion?: 'general' | 'birthday' | 'anniversary' | 'family-reunion' | 'business-lunch' | 'celebration';
  dietaryNotes?: string;
  specialRequests?: string;
  createdAt: string;
  status: 'confirmed' | 'pending' | 'cancelled';
}

export interface GalleryImage {
  id: string;
  title: string;
  category: 'all' | 'dishes' | 'ambiance' | 'family' | 'heritage';
  url: string;
  description: string;
  aspect?: string;
}

export interface Review {
  id: string;
  author: string;
  location: string;
  rating: number;
  date: string;
  comment: string;
  source: 'Google Reviews' | 'TripAdvisor' | 'DineOut' | 'Zomato';
  highlightDish: string;
}

export interface PlatterItem {
  item: MenuItem;
  quantity: number;
  instructions?: string;
}
